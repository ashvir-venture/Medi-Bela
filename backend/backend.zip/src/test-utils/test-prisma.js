"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FAKE_KEY_CONFIG = void 0;
exports.makeTestPrisma = makeTestPrisma;
exports.resetDb = resetDb;
exports.makeUser = makeUser;
function makeTestPrisma() {
    const url = process.env.TEST_DATABASE_URL;
    if (!url)
        return null;
    const { PrismaClient } = require('@prisma/client');
    if (process.env.PRISMA_TEST_PG_ADAPTER === '1') {
        const { PrismaPg } = require('@prisma/adapter-pg');
        return new PrismaClient({ adapter: new PrismaPg({ connectionString: url }) });
    }
    return new PrismaClient({ datasources: { db: { url } } });
}
async function resetDb(prisma) {
    await prisma.$executeRawUnsafe('TRUNCATE TABLE notifications, device_tokens, medicine_doses, medicine_routines, family_invitations, family_members, families, users RESTART IDENTITY CASCADE');
}
let phoneSeq = 0;
function makeUser(prisma, name, extra = {}) {
    phoneSeq += 1;
    return prisma.user.create({
        data: { phone: `+88017000${String(phoneSeq).padStart(5, '0')}`, name, passwordHash: 'x', ...extra },
    });
}
exports.FAKE_KEY_CONFIG = {
    getOrThrow: () => Buffer.alloc(32, 7).toString('base64'),
    get: () => undefined,
};

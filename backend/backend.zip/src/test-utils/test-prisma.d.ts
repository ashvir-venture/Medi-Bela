export declare function makeTestPrisma(): any | null;
export declare function resetDb(prisma: any): Promise<void>;
export declare function makeUser(prisma: any, name: string, extra?: Record<string, unknown>): any;
export declare const FAKE_KEY_CONFIG: any;

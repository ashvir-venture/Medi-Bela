export declare class MedicineScheduleModule {
}

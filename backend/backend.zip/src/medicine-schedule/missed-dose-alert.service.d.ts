import { PrismaService } from '../prisma/prisma.service';
import { NotificationsService } from '../notifications/notifications.service';
export declare class MissedDoseAlertService {
    private readonly prisma;
    private readonly notifications;
    private readonly logger;
    private running;
    constructor(prisma: PrismaService, notifications: NotificationsService);
    handleCron(): Promise<void>;
    run(now?: Date): Promise<{
        swept: number;
        alerted: number;
    }>;
    private alertFamily;
}

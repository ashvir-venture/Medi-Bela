import { DoseStatus } from '@prisma/client';
export type DoseDisplayStatus = 'UPCOMING' | 'DUE' | 'TAKEN' | 'MISSED' | 'SKIPPED';
export declare function missedGraceMinutes(): number;
export declare function missedCutoff(reference?: Date): Date;
export declare function computeDisplayStatus(status: DoseStatus, scheduledAt: Date, now?: Date): DoseDisplayStatus;
export declare function effectiveStatus(status: DoseStatus, scheduledAt: Date, now?: Date): DoseStatus;

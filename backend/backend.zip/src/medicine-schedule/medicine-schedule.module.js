"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MedicineScheduleModule = void 0;
const common_1 = require("@nestjs/common");
const medicine_schedule_controller_1 = require("./medicine-schedule.controller");
const medicine_schedule_service_1 = require("./medicine-schedule.service");
const missed_dose_alert_service_1 = require("./missed-dose-alert.service");
let MedicineScheduleModule = class MedicineScheduleModule {
};
exports.MedicineScheduleModule = MedicineScheduleModule;
exports.MedicineScheduleModule = MedicineScheduleModule = __decorate([
    (0, common_1.Module)({
        controllers: [medicine_schedule_controller_1.MedicineScheduleController],
        providers: [medicine_schedule_service_1.MedicineScheduleService, missed_dose_alert_service_1.MissedDoseAlertService],
    })
], MedicineScheduleModule);

import { PrismaService } from '../prisma/prisma.service';
export declare class MedicineScheduleService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    getActiveRoutines(userId: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        prescriptionMedicineId: string | null;
        medicineName: string;
        dosage: string;
        frequency: string;
        startDate: Date;
        endDate: Date | null;
        active: boolean;
    }[]>;
    getRoutineDetail(userId: string, routineId: string): Promise<{
        doses: ({
            id: string;
            createdAt: Date;
            updatedAt: Date;
            userId: string;
            routineId: string;
            scheduledAt: Date;
            status: import("@prisma/client").$Enums.DoseStatus;
            takenAt: Date | null;
            familyAlertProcessedAt: Date | null;
        } & {
            displayStatus: import("./lib/dose-status.util").DoseDisplayStatus;
        })[];
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        prescriptionMedicineId: string | null;
        medicineName: string;
        dosage: string;
        frequency: string;
        startDate: Date;
        endDate: Date | null;
        active: boolean;
    }>;
    getTodaysSchedule(userId: string): Promise<({
        routine: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            userId: string;
            prescriptionMedicineId: string | null;
            medicineName: string;
            dosage: string;
            frequency: string;
            startDate: Date;
            endDate: Date | null;
            active: boolean;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        routineId: string;
        scheduledAt: Date;
        status: import("@prisma/client").$Enums.DoseStatus;
        takenAt: Date | null;
        familyAlertProcessedAt: Date | null;
    } & {
        displayStatus: import("./lib/dose-status.util").DoseDisplayStatus;
    })[]>;
    getUpcomingDoses(userId: string, days?: number): Promise<({
        routine: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            userId: string;
            prescriptionMedicineId: string | null;
            medicineName: string;
            dosage: string;
            frequency: string;
            startDate: Date;
            endDate: Date | null;
            active: boolean;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        routineId: string;
        scheduledAt: Date;
        status: import("@prisma/client").$Enums.DoseStatus;
        takenAt: Date | null;
        familyAlertProcessedAt: Date | null;
    } & {
        displayStatus: import("./lib/dose-status.util").DoseDisplayStatus;
    })[]>;
    getDoseDetail(userId: string, doseId: string): Promise<{
        routine: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            userId: string;
            prescriptionMedicineId: string | null;
            medicineName: string;
            dosage: string;
            frequency: string;
            startDate: Date;
            endDate: Date | null;
            active: boolean;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        routineId: string;
        scheduledAt: Date;
        status: import("@prisma/client").$Enums.DoseStatus;
        takenAt: Date | null;
        familyAlertProcessedAt: Date | null;
    } & {
        displayStatus: import("./lib/dose-status.util").DoseDisplayStatus;
    }>;
    getDoseHistory(userId: string, from: Date, to: Date): Promise<({
        routine: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            userId: string;
            prescriptionMedicineId: string | null;
            medicineName: string;
            dosage: string;
            frequency: string;
            startDate: Date;
            endDate: Date | null;
            active: boolean;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        routineId: string;
        scheduledAt: Date;
        status: import("@prisma/client").$Enums.DoseStatus;
        takenAt: Date | null;
        familyAlertProcessedAt: Date | null;
    } & {
        displayStatus: import("./lib/dose-status.util").DoseDisplayStatus;
    })[]>;
    markDoseTaken(userId: string, doseId: string, takenAt?: string): Promise<{
        routine: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            userId: string;
            prescriptionMedicineId: string | null;
            medicineName: string;
            dosage: string;
            frequency: string;
            startDate: Date;
            endDate: Date | null;
            active: boolean;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        routineId: string;
        scheduledAt: Date;
        status: import("@prisma/client").$Enums.DoseStatus;
        takenAt: Date | null;
        familyAlertProcessedAt: Date | null;
    } & {
        displayStatus: import("./lib/dose-status.util").DoseDisplayStatus;
    }>;
    getChangesSince(userId: string, since: Date): Promise<{
        routines: {
            doses: ({
                id: string;
                createdAt: Date;
                updatedAt: Date;
                userId: string;
                routineId: string;
                scheduledAt: Date;
                status: import("@prisma/client").$Enums.DoseStatus;
                takenAt: Date | null;
                familyAlertProcessedAt: Date | null;
            } & {
                displayStatus: import("./lib/dose-status.util").DoseDisplayStatus;
            })[];
            id: string;
            createdAt: Date;
            updatedAt: Date;
            userId: string;
            prescriptionMedicineId: string | null;
            medicineName: string;
            dosage: string;
            frequency: string;
            startDate: Date;
            endDate: Date | null;
            active: boolean;
        }[];
        syncedAt: Date;
    }>;
    private sweepMissedDoses;
    private withDisplayStatus;
    private dayBounds;
}

"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MedicineScheduleService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../prisma/prisma.service");
const dose_status_util_1 = require("./lib/dose-status.util");
const time_util_1 = require("../common/utils/time.util");
let MedicineScheduleService = class MedicineScheduleService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async getActiveRoutines(userId) {
        return this.prisma.medicineRoutine.findMany({
            where: { userId, active: true },
            orderBy: { startDate: 'asc' },
        });
    }
    async getRoutineDetail(userId, routineId) {
        await this.sweepMissedDoses(userId);
        const routine = await this.prisma.medicineRoutine.findFirst({
            where: { id: routineId, userId },
            include: { doses: { orderBy: { scheduledAt: 'asc' } } },
        });
        if (!routine)
            return null;
        return { ...routine, doses: routine.doses.map((d) => this.withDisplayStatus(d)) };
    }
    async getTodaysSchedule(userId) {
        await this.sweepMissedDoses(userId);
        const { start, end } = this.dayBounds(new Date());
        const doses = await this.prisma.medicineDose.findMany({
            where: { userId, scheduledAt: { gte: start, lt: end } },
            include: { routine: true },
            orderBy: { scheduledAt: 'asc' },
        });
        return doses.map((d) => this.withDisplayStatus(d));
    }
    async getUpcomingDoses(userId, days = 7) {
        await this.sweepMissedDoses(userId);
        const { end: todayEnd } = this.dayBounds(new Date());
        const windowEnd = (0, time_util_1.addAppDays)(todayEnd, days);
        const doses = await this.prisma.medicineDose.findMany({
            where: { userId, scheduledAt: { gte: todayEnd, lt: windowEnd } },
            include: { routine: true },
            orderBy: { scheduledAt: 'asc' },
        });
        return doses.map((d) => this.withDisplayStatus(d));
    }
    async getDoseDetail(userId, doseId) {
        await this.sweepMissedDoses(userId);
        const dose = await this.prisma.medicineDose.findUnique({
            where: { id: doseId },
            include: { routine: true },
        });
        if (!dose)
            throw new common_1.NotFoundException('Dose not found');
        if (dose.userId !== userId) {
            throw new common_1.NotFoundException('Dose not found');
        }
        return this.withDisplayStatus(dose);
    }
    async getDoseHistory(userId, from, to) {
        await this.sweepMissedDoses(userId);
        const doses = await this.prisma.medicineDose.findMany({
            where: { userId, scheduledAt: { gte: from, lte: to } },
            include: { routine: true },
            orderBy: { scheduledAt: 'desc' },
        });
        return doses.map((d) => this.withDisplayStatus(d));
    }
    async markDoseTaken(userId, doseId, takenAt) {
        const dose = await this.prisma.medicineDose.findUnique({ where: { id: doseId } });
        if (!dose)
            throw new common_1.NotFoundException('Dose not found');
        if (dose.userId !== userId)
            throw new common_1.NotFoundException('Dose not found');
        if (dose.status === client_1.DoseStatus.TAKEN) {
            return this.getDoseDetail(userId, doseId);
        }
        if (dose.status === client_1.DoseStatus.SKIPPED) {
            throw new common_1.ForbiddenException('This dose was skipped and cannot be marked taken');
        }
        await this.prisma.medicineDose.update({
            where: { id: doseId },
            data: {
                status: client_1.DoseStatus.TAKEN,
                takenAt: takenAt ? new Date(takenAt) : new Date(),
            },
        });
        return this.getDoseDetail(userId, doseId);
    }
    async getChangesSince(userId, since) {
        await this.sweepMissedDoses(userId);
        const routines = await this.prisma.medicineRoutine.findMany({
            where: { userId, updatedAt: { gt: since } },
            include: { doses: { orderBy: { scheduledAt: 'asc' } } },
            orderBy: { updatedAt: 'asc' },
        });
        return {
            routines: routines.map((r) => ({ ...r, doses: r.doses.map((d) => this.withDisplayStatus(d)) })),
            syncedAt: new Date(),
        };
    }
    async sweepMissedDoses(userId) {
        await this.prisma.medicineDose.updateMany({
            where: {
                userId,
                status: client_1.DoseStatus.PENDING,
                scheduledAt: { lt: (0, dose_status_util_1.missedCutoff)() },
            },
            data: { status: client_1.DoseStatus.MISSED },
        });
    }
    withDisplayStatus(dose) {
        return { ...dose, displayStatus: (0, dose_status_util_1.computeDisplayStatus)(dose.status, dose.scheduledAt) };
    }
    dayBounds(reference) {
        return (0, time_util_1.appDayBounds)(reference);
    }
};
exports.MedicineScheduleService = MedicineScheduleService;
exports.MedicineScheduleService = MedicineScheduleService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], MedicineScheduleService);

export declare class MarkDoseTakenDto {
    takenAt?: string;
}

"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var MissedDoseAlertService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.MissedDoseAlertService = void 0;
const common_1 = require("@nestjs/common");
const schedule_1 = require("@nestjs/schedule");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../prisma/prisma.service");
const notifications_service_1 = require("../notifications/notifications.service");
const notification_messages_1 = require("../notifications/notification-messages");
const dose_status_util_1 = require("./lib/dose-status.util");
const BATCH_SIZE = 200;
function alertMaxAgeMs() {
    const raw = Number(process.env.MISSED_ALERT_MAX_AGE_MINUTES);
    return (Number.isFinite(raw) && raw > 0 ? raw : 360) * 60_000;
}
let MissedDoseAlertService = MissedDoseAlertService_1 = class MissedDoseAlertService {
    prisma;
    notifications;
    logger = new common_1.Logger(MissedDoseAlertService_1.name);
    running = false;
    constructor(prisma, notifications) {
        this.prisma = prisma;
        this.notifications = notifications;
    }
    async handleCron() {
        if (this.running || process.env.MISSED_DOSE_JOB_ENABLED === 'false')
            return;
        this.running = true;
        try {
            await this.run();
        }
        catch (err) {
            this.logger.error(`Missed-dose job failed: ${err.message}`);
        }
        finally {
            this.running = false;
        }
    }
    async run(now = new Date()) {
        const sweep = await this.prisma.medicineDose.updateMany({
            where: { status: client_1.DoseStatus.PENDING, scheduledAt: { lt: (0, dose_status_util_1.missedCutoff)(now) } },
            data: { status: client_1.DoseStatus.MISSED },
        });
        const staleBefore = new Date(now.getTime() - alertMaxAgeMs());
        await this.prisma.medicineDose.updateMany({
            where: {
                status: client_1.DoseStatus.MISSED,
                familyAlertProcessedAt: null,
                scheduledAt: { lt: staleBefore },
            },
            data: { familyAlertProcessedAt: now },
        });
        const candidates = await this.prisma.medicineDose.findMany({
            where: {
                status: client_1.DoseStatus.MISSED,
                familyAlertProcessedAt: null,
                scheduledAt: { gte: staleBefore },
            },
            orderBy: { scheduledAt: 'asc' },
            take: BATCH_SIZE,
            select: {
                id: true,
                userId: true,
                user: { select: { name: true, accountStatus: true, profileVisibleToFamily: true } },
            },
        });
        let alerted = 0;
        for (const dose of candidates) {
            try {
                alerted += await this.alertFamily(dose, now);
            }
            catch (err) {
                this.logger.error(`Family alert failed for dose ${dose.id}: ${err.message}`);
            }
        }
        if (sweep.count > 0 || alerted > 0) {
            this.logger.log(`Missed-dose run: ${sweep.count} newly missed, ${alerted} family alerts created`);
        }
        return { swept: sweep.count, alerted };
    }
    async alertFamily(dose, now) {
        let recipients = [];
        if (dose.user.profileVisibleToFamily && dose.user.accountStatus === client_1.AccountStatus.ACTIVE) {
            const membership = await this.prisma.familyMember.findUnique({
                where: { userId: dose.userId },
                select: { familyId: true },
            });
            if (membership) {
                const others = await this.prisma.familyMember.findMany({
                    where: {
                        familyId: membership.familyId,
                        userId: { not: dose.userId },
                        user: { accountStatus: client_1.AccountStatus.ACTIVE },
                    },
                    select: { user: { select: { id: true, languagePreference: true } } },
                });
                recipients = others.map((o) => o.user);
            }
        }
        const createdIds = await this.prisma.$transaction(async (tx) => {
            const claim = await tx.medicineDose.updateMany({
                where: { id: dose.id, status: client_1.DoseStatus.MISSED, familyAlertProcessedAt: null },
                data: { familyAlertProcessedAt: now },
            });
            if (claim.count === 0)
                return [];
            const rows = recipients.map((r) => {
                const copy = notification_messages_1.messages.missedDoseFamily(r.languagePreference, dose.user.name);
                return {
                    userId: r.id,
                    type: client_1.NotificationType.MISSED_DOSE_FAMILY_ALERT,
                    title: copy.title,
                    body: copy.body,
                    relatedEntityId: dose.id,
                    data: { memberUserId: dose.userId },
                };
            });
            return this.notifications.createMany(rows, tx);
        });
        await this.notifications.dispatch(createdIds);
        return createdIds.length;
    }
};
exports.MissedDoseAlertService = MissedDoseAlertService;
__decorate([
    (0, schedule_1.Cron)(schedule_1.CronExpression.EVERY_MINUTE),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], MissedDoseAlertService.prototype, "handleCron", null);
exports.MissedDoseAlertService = MissedDoseAlertService = MissedDoseAlertService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        notifications_service_1.NotificationsService])
], MissedDoseAlertService);

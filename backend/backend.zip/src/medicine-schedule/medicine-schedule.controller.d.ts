import { MedicineScheduleService } from './medicine-schedule.service';
import { MarkDoseTakenDto } from './dto/mark-dose-taken.dto';
export declare class MedicineScheduleController {
    private readonly schedule;
    constructor(schedule: MedicineScheduleService);
    getActiveRoutines(userId: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        prescriptionMedicineId: string | null;
        medicineName: string;
        dosage: string;
        frequency: string;
        startDate: Date;
        endDate: Date | null;
        active: boolean;
    }[]>;
    getRoutine(userId: string, id: string): Promise<{
        doses: ({
            id: string;
            createdAt: Date;
            updatedAt: Date;
            userId: string;
            routineId: string;
            scheduledAt: Date;
            status: import("@prisma/client").$Enums.DoseStatus;
            takenAt: Date | null;
            familyAlertProcessedAt: Date | null;
        } & {
            displayStatus: import("./lib/dose-status.util").DoseDisplayStatus;
        })[];
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        prescriptionMedicineId: string | null;
        medicineName: string;
        dosage: string;
        frequency: string;
        startDate: Date;
        endDate: Date | null;
        active: boolean;
    }>;
    getToday(userId: string): Promise<({
        routine: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            userId: string;
            prescriptionMedicineId: string | null;
            medicineName: string;
            dosage: string;
            frequency: string;
            startDate: Date;
            endDate: Date | null;
            active: boolean;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        routineId: string;
        scheduledAt: Date;
        status: import("@prisma/client").$Enums.DoseStatus;
        takenAt: Date | null;
        familyAlertProcessedAt: Date | null;
    } & {
        displayStatus: import("./lib/dose-status.util").DoseDisplayStatus;
    })[]>;
    getUpcoming(userId: string, days?: string): Promise<({
        routine: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            userId: string;
            prescriptionMedicineId: string | null;
            medicineName: string;
            dosage: string;
            frequency: string;
            startDate: Date;
            endDate: Date | null;
            active: boolean;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        routineId: string;
        scheduledAt: Date;
        status: import("@prisma/client").$Enums.DoseStatus;
        takenAt: Date | null;
        familyAlertProcessedAt: Date | null;
    } & {
        displayStatus: import("./lib/dose-status.util").DoseDisplayStatus;
    })[]>;
    getChanges(userId: string, since?: string): Promise<{
        routines: {
            doses: ({
                id: string;
                createdAt: Date;
                updatedAt: Date;
                userId: string;
                routineId: string;
                scheduledAt: Date;
                status: import("@prisma/client").$Enums.DoseStatus;
                takenAt: Date | null;
                familyAlertProcessedAt: Date | null;
            } & {
                displayStatus: import("./lib/dose-status.util").DoseDisplayStatus;
            })[];
            id: string;
            createdAt: Date;
            updatedAt: Date;
            userId: string;
            prescriptionMedicineId: string | null;
            medicineName: string;
            dosage: string;
            frequency: string;
            startDate: Date;
            endDate: Date | null;
            active: boolean;
        }[];
        syncedAt: Date;
    }>;
    getDoseHistory(userId: string, from?: string, to?: string): Promise<({
        routine: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            userId: string;
            prescriptionMedicineId: string | null;
            medicineName: string;
            dosage: string;
            frequency: string;
            startDate: Date;
            endDate: Date | null;
            active: boolean;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        routineId: string;
        scheduledAt: Date;
        status: import("@prisma/client").$Enums.DoseStatus;
        takenAt: Date | null;
        familyAlertProcessedAt: Date | null;
    } & {
        displayStatus: import("./lib/dose-status.util").DoseDisplayStatus;
    })[]>;
    getDose(userId: string, id: string): Promise<{
        routine: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            userId: string;
            prescriptionMedicineId: string | null;
            medicineName: string;
            dosage: string;
            frequency: string;
            startDate: Date;
            endDate: Date | null;
            active: boolean;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        routineId: string;
        scheduledAt: Date;
        status: import("@prisma/client").$Enums.DoseStatus;
        takenAt: Date | null;
        familyAlertProcessedAt: Date | null;
    } & {
        displayStatus: import("./lib/dose-status.util").DoseDisplayStatus;
    }>;
    markDoseTaken(userId: string, id: string, dto: MarkDoseTakenDto): Promise<{
        routine: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            userId: string;
            prescriptionMedicineId: string | null;
            medicineName: string;
            dosage: string;
            frequency: string;
            startDate: Date;
            endDate: Date | null;
            active: boolean;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        routineId: string;
        scheduledAt: Date;
        status: import("@prisma/client").$Enums.DoseStatus;
        takenAt: Date | null;
        familyAlertProcessedAt: Date | null;
    } & {
        displayStatus: import("./lib/dose-status.util").DoseDisplayStatus;
    }>;
}

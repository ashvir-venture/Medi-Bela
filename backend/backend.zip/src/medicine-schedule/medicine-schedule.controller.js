"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MedicineScheduleController = void 0;
const common_1 = require("@nestjs/common");
const medicine_schedule_service_1 = require("./medicine-schedule.service");
const current_user_decorator_1 = require("../common/decorators/current-user.decorator");
const mark_dose_taken_dto_1 = require("./dto/mark-dose-taken.dto");
let MedicineScheduleController = class MedicineScheduleController {
    schedule;
    constructor(schedule) {
        this.schedule = schedule;
    }
    getActiveRoutines(userId) {
        return this.schedule.getActiveRoutines(userId);
    }
    getRoutine(userId, id) {
        return this.schedule.getRoutineDetail(userId, id);
    }
    getToday(userId) {
        return this.schedule.getTodaysSchedule(userId);
    }
    getUpcoming(userId, days) {
        const parsedDays = days ? Number(days) : 7;
        if (!Number.isInteger(parsedDays) || parsedDays < 1 || parsedDays > 30) {
            throw new common_1.BadRequestException('days must be an integer between 1 and 30');
        }
        return this.schedule.getUpcomingDoses(userId, parsedDays);
    }
    getChanges(userId, since) {
        const sinceDate = since ? new Date(since) : new Date(0);
        if (Number.isNaN(sinceDate.getTime())) {
            throw new common_1.BadRequestException('since must be a valid ISO timestamp');
        }
        return this.schedule.getChangesSince(userId, sinceDate);
    }
    getDoseHistory(userId, from, to) {
        const toDate = to ? new Date(to) : new Date();
        const fromDate = from ? new Date(from) : new Date(toDate.getTime() - 30 * 24 * 60 * 60 * 1000);
        if (Number.isNaN(fromDate.getTime()) || Number.isNaN(toDate.getTime())) {
            throw new common_1.BadRequestException('from/to must be valid ISO timestamps');
        }
        return this.schedule.getDoseHistory(userId, fromDate, toDate);
    }
    getDose(userId, id) {
        return this.schedule.getDoseDetail(userId, id);
    }
    markDoseTaken(userId, id, dto) {
        return this.schedule.markDoseTaken(userId, id, dto.takenAt);
    }
};
exports.MedicineScheduleController = MedicineScheduleController;
__decorate([
    (0, common_1.Get)('routines'),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], MedicineScheduleController.prototype, "getActiveRoutines", null);
__decorate([
    (0, common_1.Get)('routines/:id'),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], MedicineScheduleController.prototype, "getRoutine", null);
__decorate([
    (0, common_1.Get)('today'),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], MedicineScheduleController.prototype, "getToday", null);
__decorate([
    (0, common_1.Get)('upcoming'),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, common_1.Query)('days')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], MedicineScheduleController.prototype, "getUpcoming", null);
__decorate([
    (0, common_1.Get)('changes'),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, common_1.Query)('since')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], MedicineScheduleController.prototype, "getChanges", null);
__decorate([
    (0, common_1.Get)('doses/history'),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, common_1.Query)('from')),
    __param(2, (0, common_1.Query)('to')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], MedicineScheduleController.prototype, "getDoseHistory", null);
__decorate([
    (0, common_1.Get)('doses/:id'),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], MedicineScheduleController.prototype, "getDose", null);
__decorate([
    (0, common_1.Post)('doses/:id/taken'),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, mark_dose_taken_dto_1.MarkDoseTakenDto]),
    __metadata("design:returntype", void 0)
], MedicineScheduleController.prototype, "markDoseTaken", null);
exports.MedicineScheduleController = MedicineScheduleController = __decorate([
    (0, common_1.Controller)('medicine-schedule'),
    __metadata("design:paramtypes", [medicine_schedule_service_1.MedicineScheduleService])
], MedicineScheduleController);

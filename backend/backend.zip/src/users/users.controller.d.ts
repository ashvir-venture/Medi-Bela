import { UsersService } from './users.service';
import { UpdateProfileDto } from './dto/update-profile.dto';
export declare class UsersController {
    private readonly usersService;
    constructor(usersService: UsersService);
    getMe(userId: string): Promise<import("../common/utils/sanitize-user").SafeUser>;
    updateMe(userId: string, dto: UpdateProfileDto): Promise<import("../common/utils/sanitize-user").SafeUser>;
}

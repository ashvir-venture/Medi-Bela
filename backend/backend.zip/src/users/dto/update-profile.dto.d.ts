import { Language } from '@prisma/client';
export declare class UpdateProfileDto {
    name?: string;
    address?: string;
    languagePreference?: Language;
    notificationsEnabled?: boolean;
    profileVisibleToFamily?: boolean;
}

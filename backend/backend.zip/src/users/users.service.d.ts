import { User } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { SafeUser } from '../common/utils/sanitize-user';
import { UpdateProfileDto } from './dto/update-profile.dto';
export declare class UsersService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    getById(userId: string): Promise<SafeUser>;
    updateProfile(userId: string, dto: UpdateProfileDto): Promise<SafeUser>;
    findByPhone(phone: string): Promise<User | null>;
}

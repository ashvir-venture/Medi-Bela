export declare class FamilyModule {
}

import { PrismaService } from '../prisma/prisma.service';
import { NotificationsService } from '../notifications/notifications.service';
import { CreateFamilyDto } from './dto/create-family.dto';
import { InviteMemberDto } from './dto/invite-member.dto';
export declare class FamilyService {
    private readonly prisma;
    private readonly notifications;
    constructor(prisma: PrismaService, notifications: NotificationsService);
    private getOwnMembership;
    private requireMembership;
    createFamily(userId: string, dto: CreateFamilyDto): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        members: {
            id: string;
            role: import("@prisma/client").$Enums.FamilyRole;
            joinedAt: Date;
            user: {
                id: string;
                name: string;
                phone: string;
                address: string;
            };
        }[];
    }>;
    getMyFamily(userId: string): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        members: {
            id: string;
            role: import("@prisma/client").$Enums.FamilyRole;
            joinedAt: Date;
            user: {
                id: string;
                name: string;
                phone: string;
                address: string;
            };
        }[];
    }>;
    private loadFamily;
    listMembers(userId: string): Promise<{
        familyMemberId: string;
        role: import("@prisma/client").$Enums.FamilyRole;
        joinedAt: Date;
        user: {
            id: string;
            name: string;
            phone: string;
            address: string;
        };
    }[]>;
    getMembersStatusSummary(userId: string): Promise<{
        date: string;
        members: ({
            userId: string;
            name: string;
            shared: false;
            today?: undefined;
        } | {
            userId: string;
            name: string;
            shared: true;
            today: {
                total: number;
                taken: number;
                missed: number;
                pending: number;
            };
        })[];
    }>;
    getMemberStatus(userId: string, memberUserId: string): Promise<{
        member: {
            userId: string;
            name: string;
        };
        shared: false;
        today: any;
        doses: any[];
    } | {
        member: {
            userId: string;
            name: string;
        };
        shared: true;
        today: {
            total: number;
            taken: number;
            missed: number;
            pending: number;
        };
        doses: {
            medicineName: string;
            scheduledAt: Date;
            status: import("@prisma/client").$Enums.DoseStatus;
            takenAt: Date;
        }[];
    }>;
    private summarize;
    inviteMember(userId: string, dto: InviteMemberDto): Promise<{
        id: string;
        familyId: string;
        invitedPhone: string;
        status: import("@prisma/client").$Enums.InvitationStatus;
        createdAt: Date;
        expiresAt: Date;
    }>;
    listIncomingInvitations(userPhone: string): Promise<{
        id: string;
        familyId: string;
        invitedPhone: string;
        status: import("@prisma/client").$Enums.InvitationStatus;
        createdAt: Date;
        expiresAt: Date;
        family: {
            name: string;
            id: string;
        };
        invitedBy: {
            name: string;
        };
    }[]>;
    listSentInvitations(userId: string): Promise<{
        id: string;
        familyId: string;
        invitedPhone: string;
        status: import("@prisma/client").$Enums.InvitationStatus;
        createdAt: Date;
        expiresAt: Date;
    }[]>;
    acceptInvitation(userId: string, userPhone: string, invitationId: string): Promise<{
        id: string;
        status: "ACCEPTED";
    }>;
    declineInvitation(userPhone: string, invitationId: string): Promise<{
        id: string;
        status: "DECLINED";
    }>;
    private getOwnedInvitationOrThrow;
    private presentSent;
}

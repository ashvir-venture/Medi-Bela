import { FamilyService } from './family.service';
import { CreateFamilyDto } from './dto/create-family.dto';
import { InviteMemberDto } from './dto/invite-member.dto';
export declare class FamilyController {
    private readonly familyService;
    constructor(familyService: FamilyService);
    create(userId: string, dto: CreateFamilyDto): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        members: {
            id: string;
            role: import("@prisma/client").$Enums.FamilyRole;
            joinedAt: Date;
            user: {
                id: string;
                name: string;
                phone: string;
                address: string;
            };
        }[];
    }>;
    getMine(userId: string): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        members: {
            id: string;
            role: import("@prisma/client").$Enums.FamilyRole;
            joinedAt: Date;
            user: {
                id: string;
                name: string;
                phone: string;
                address: string;
            };
        }[];
    }>;
    listMembers(userId: string): Promise<{
        familyMemberId: string;
        role: import("@prisma/client").$Enums.FamilyRole;
        joinedAt: Date;
        user: {
            id: string;
            name: string;
            phone: string;
            address: string;
        };
    }[]>;
    membersStatus(userId: string): Promise<{
        date: string;
        members: ({
            userId: string;
            name: string;
            shared: false;
            today?: undefined;
        } | {
            userId: string;
            name: string;
            shared: true;
            today: {
                total: number;
                taken: number;
                missed: number;
                pending: number;
            };
        })[];
    }>;
    memberStatus(userId: string, memberUserId: string): Promise<{
        member: {
            userId: string;
            name: string;
        };
        shared: false;
        today: any;
        doses: any[];
    } | {
        member: {
            userId: string;
            name: string;
        };
        shared: true;
        today: {
            total: number;
            taken: number;
            missed: number;
            pending: number;
        };
        doses: {
            medicineName: string;
            scheduledAt: Date;
            status: import("@prisma/client").$Enums.DoseStatus;
            takenAt: Date;
        }[];
    }>;
    invite(userId: string, dto: InviteMemberDto): Promise<{
        id: string;
        familyId: string;
        invitedPhone: string;
        status: import("@prisma/client").$Enums.InvitationStatus;
        createdAt: Date;
        expiresAt: Date;
    }>;
    listInvitations(userId: string, phone: string, type?: string): Promise<{
        id: string;
        familyId: string;
        invitedPhone: string;
        status: import("@prisma/client").$Enums.InvitationStatus;
        createdAt: Date;
        expiresAt: Date;
    }[]>;
    accept(userId: string, phone: string, invitationId: string): Promise<{
        id: string;
        status: "ACCEPTED";
    }>;
    decline(phone: string, invitationId: string): Promise<{
        id: string;
        status: "DECLINED";
    }>;
}

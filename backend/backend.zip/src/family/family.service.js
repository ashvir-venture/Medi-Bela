"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FamilyService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../prisma/prisma.service");
const notifications_service_1 = require("../notifications/notifications.service");
const notification_messages_1 = require("../notifications/notification-messages");
const time_util_1 = require("../common/utils/time.util");
const phone_util_1 = require("../common/utils/phone.util");
const dose_status_util_1 = require("../medicine-schedule/lib/dose-status.util");
const INVITATION_TTL_DAYS = 7;
const MAX_PENDING_INVITATIONS = 20;
const MEMBER_USER_SELECT = {
    id: true,
    name: true,
    phone: true,
    address: true,
    profileVisibleToFamily: true,
};
function presentUser(user) {
    return {
        id: user.id,
        name: user.name,
        phone: user.phone,
        address: user.profileVisibleToFamily ? user.address : null,
    };
}
let FamilyService = class FamilyService {
    prisma;
    notifications;
    constructor(prisma, notifications) {
        this.prisma = prisma;
        this.notifications = notifications;
    }
    getOwnMembership(userId) {
        return this.prisma.familyMember.findUnique({ where: { userId } });
    }
    async requireMembership(userId) {
        const membership = await this.getOwnMembership(userId);
        if (!membership)
            throw new common_1.NotFoundException('You are not part of a family yet');
        return membership;
    }
    async createFamily(userId, dto) {
        try {
            const family = await this.prisma.family.create({
                data: { name: dto.name, members: { create: { userId, role: client_1.FamilyRole.OWNER } } },
                select: { id: true },
            });
            return this.loadFamily(family.id);
        }
        catch (err) {
            if (err instanceof client_1.Prisma.PrismaClientKnownRequestError && err.code === 'P2002') {
                throw new common_1.ConflictException('You already belong to a family');
            }
            throw err;
        }
    }
    async getMyFamily(userId) {
        const membership = await this.requireMembership(userId);
        return this.loadFamily(membership.familyId);
    }
    async loadFamily(familyId) {
        const family = await this.prisma.family.findUnique({
            where: { id: familyId },
            include: {
                members: {
                    include: { user: { select: MEMBER_USER_SELECT } },
                    orderBy: { joinedAt: 'asc' },
                },
            },
        });
        if (!family)
            throw new common_1.NotFoundException('You are not part of a family yet');
        return {
            id: family.id,
            name: family.name,
            createdAt: family.createdAt,
            members: family.members.map((m) => ({
                id: m.id,
                role: m.role,
                joinedAt: m.joinedAt,
                user: presentUser(m.user),
            })),
        };
    }
    async listMembers(userId) {
        const membership = await this.requireMembership(userId);
        const members = await this.prisma.familyMember.findMany({
            where: { familyId: membership.familyId },
            include: { user: { select: MEMBER_USER_SELECT } },
            orderBy: { joinedAt: 'asc' },
        });
        return members.map((m) => ({
            familyMemberId: m.id,
            role: m.role,
            joinedAt: m.joinedAt,
            user: presentUser(m.user),
        }));
    }
    async getMembersStatusSummary(userId) {
        const membership = await this.requireMembership(userId);
        const members = await this.prisma.familyMember.findMany({
            where: { familyId: membership.familyId, userId: { not: userId } },
            include: { user: { select: { id: true, name: true, profileVisibleToFamily: true } } },
            orderBy: { joinedAt: 'asc' },
        });
        const { start, end } = (0, time_util_1.appDayBounds)(new Date());
        const sharingIds = members.filter((m) => m.user.profileVisibleToFamily).map((m) => m.userId);
        const doses = sharingIds.length
            ? await this.prisma.medicineDose.findMany({
                where: { userId: { in: sharingIds }, scheduledAt: { gte: start, lt: end } },
                select: { userId: true, status: true, scheduledAt: true },
            })
            : [];
        return {
            date: start.toISOString(),
            members: members.map((m) => {
                if (!m.user.profileVisibleToFamily) {
                    return { userId: m.userId, name: m.user.name, shared: false };
                }
                const mine = doses
                    .filter((d) => d.userId === m.userId)
                    .map((d) => (0, dose_status_util_1.effectiveStatus)(d.status, d.scheduledAt));
                return {
                    userId: m.userId,
                    name: m.user.name,
                    shared: true,
                    today: this.summarize(mine),
                };
            }),
        };
    }
    async getMemberStatus(userId, memberUserId) {
        const membership = await this.requireMembership(userId);
        const target = await this.prisma.familyMember.findFirst({
            where: { userId: memberUserId, familyId: membership.familyId },
            include: { user: { select: { id: true, name: true, profileVisibleToFamily: true } } },
        });
        if (!target)
            throw new common_1.NotFoundException('Family member not found');
        const member = { userId: target.userId, name: target.user.name };
        const isSelf = target.userId === userId;
        if (!isSelf && !target.user.profileVisibleToFamily) {
            return { member, shared: false, today: null, doses: [] };
        }
        const { start, end } = (0, time_util_1.appDayBounds)(new Date());
        const rows = await this.prisma.medicineDose.findMany({
            where: { userId: target.userId, scheduledAt: { gte: start, lt: end } },
            orderBy: { scheduledAt: 'asc' },
            select: {
                scheduledAt: true,
                status: true,
                takenAt: true,
                routine: { select: { medicineName: true } },
            },
        });
        const doses = rows.map((d) => ({
            medicineName: d.routine.medicineName,
            scheduledAt: d.scheduledAt,
            status: (0, dose_status_util_1.effectiveStatus)(d.status, d.scheduledAt),
            takenAt: d.takenAt,
        }));
        return {
            member,
            shared: true,
            today: this.summarize(doses.map((d) => d.status)),
            doses,
        };
    }
    summarize(statuses) {
        return {
            total: statuses.length,
            taken: statuses.filter((s) => s === client_1.DoseStatus.TAKEN).length,
            missed: statuses.filter((s) => s === client_1.DoseStatus.MISSED).length,
            pending: statuses.filter((s) => s === client_1.DoseStatus.PENDING).length,
        };
    }
    async inviteMember(userId, dto) {
        const membership = await this.requireMembership(userId);
        if (membership.role !== client_1.FamilyRole.OWNER) {
            throw new common_1.ForbiddenException('Only the family owner can invite members');
        }
        const phone = (0, phone_util_1.normalizePhone)(dto.phone);
        const inviter = await this.prisma.user.findUnique({
            where: { id: userId },
            select: { phone: true, name: true },
        });
        if (!inviter)
            throw new common_1.NotFoundException('User not found');
        if (phone === inviter.phone)
            throw new common_1.BadRequestException('You cannot invite yourself');
        const alreadyMember = await this.prisma.familyMember.findFirst({
            where: { familyId: membership.familyId, user: { phone } },
            select: { id: true },
        });
        if (alreadyMember)
            throw new common_1.ConflictException('This person is already a family member');
        const now = new Date();
        await this.prisma.familyInvitation.updateMany({
            where: { familyId: membership.familyId, status: client_1.InvitationStatus.PENDING, expiresAt: { lt: now } },
            data: { status: client_1.InvitationStatus.EXPIRED },
        });
        const pending = await this.prisma.familyInvitation.findMany({
            where: { familyId: membership.familyId, status: client_1.InvitationStatus.PENDING },
            select: { invitedPhone: true },
        });
        if (pending.some((p) => p.invitedPhone === phone)) {
            throw new common_1.ConflictException('An invitation to this phone number is already pending');
        }
        if (pending.length >= MAX_PENDING_INVITATIONS) {
            throw new common_1.ConflictException('Too many pending invitations. Wait for replies or for them to expire.');
        }
        const expiresAt = new Date(now.getTime() + INVITATION_TTL_DAYS * 86_400_000);
        let invitation;
        try {
            invitation = await this.prisma.familyInvitation.create({
                data: { familyId: membership.familyId, invitedPhone: phone, invitedById: userId, expiresAt },
            });
        }
        catch (err) {
            if (err instanceof client_1.Prisma.PrismaClientKnownRequestError && err.code === 'P2002') {
                throw new common_1.ConflictException('An invitation to this phone number is already pending');
            }
            throw err;
        }
        const invitee = await this.prisma.user.findUnique({
            where: { phone },
            select: { id: true, languagePreference: true, accountStatus: true },
        });
        if (invitee && invitee.accountStatus === 'ACTIVE') {
            const copy = notification_messages_1.messages.familyInvitation(invitee.languagePreference, inviter.name);
            await this.notifications.notify([
                {
                    userId: invitee.id,
                    type: client_1.NotificationType.SYSTEM,
                    title: copy.title,
                    body: copy.body,
                    relatedEntityId: invitation.id,
                    data: { kind: 'family_invitation' },
                },
            ]);
        }
        return this.presentSent(invitation);
    }
    async listIncomingInvitations(userPhone) {
        const phone = (0, phone_util_1.normalizePhone)(userPhone);
        await this.prisma.familyInvitation.updateMany({
            where: { invitedPhone: phone, status: client_1.InvitationStatus.PENDING, expiresAt: { lt: new Date() } },
            data: { status: client_1.InvitationStatus.EXPIRED },
        });
        const rows = await this.prisma.familyInvitation.findMany({
            where: { invitedPhone: phone, status: client_1.InvitationStatus.PENDING },
            include: {
                family: { select: { id: true, name: true } },
                invitedBy: { select: { name: true } },
            },
            orderBy: { createdAt: 'desc' },
        });
        return rows.map((r) => ({
            id: r.id,
            familyId: r.familyId,
            invitedPhone: r.invitedPhone,
            status: r.status,
            createdAt: r.createdAt,
            expiresAt: r.expiresAt,
            family: r.family,
            invitedBy: { name: r.invitedBy.name },
        }));
    }
    async listSentInvitations(userId) {
        const membership = await this.requireMembership(userId);
        if (membership.role !== client_1.FamilyRole.OWNER) {
            throw new common_1.ForbiddenException('Only the family owner can view sent invitations');
        }
        const rows = await this.prisma.familyInvitation.findMany({
            where: {
                familyId: membership.familyId,
                status: client_1.InvitationStatus.PENDING,
                OR: [{ expiresAt: null }, { expiresAt: { gt: new Date() } }],
            },
            orderBy: { createdAt: 'desc' },
        });
        return rows.map((r) => this.presentSent(r));
    }
    async acceptInvitation(userId, userPhone, invitationId) {
        const invitation = await this.getOwnedInvitationOrThrow(invitationId, userPhone);
        try {
            return await this.prisma.$transaction(async (tx) => {
                const existing = await tx.familyMember.findUnique({ where: { userId } });
                if (existing) {
                    const size = await tx.familyMember.count({ where: { familyId: existing.familyId } });
                    if (existing.role === client_1.FamilyRole.OWNER && size === 1) {
                        await tx.family.delete({ where: { id: existing.familyId } });
                    }
                    else {
                        throw new common_1.ConflictException('You already belong to a family');
                    }
                }
                const claimed = await tx.familyInvitation.updateMany({
                    where: { id: invitation.id, status: client_1.InvitationStatus.PENDING },
                    data: { status: client_1.InvitationStatus.ACCEPTED, respondedAt: new Date() },
                });
                if (claimed.count === 0)
                    throw new common_1.ConflictException('This invitation is no longer pending');
                await tx.familyMember.create({
                    data: { familyId: invitation.familyId, userId, role: client_1.FamilyRole.MEMBER },
                });
                return { id: invitation.id, status: client_1.InvitationStatus.ACCEPTED };
            });
        }
        catch (err) {
            if (err instanceof client_1.Prisma.PrismaClientKnownRequestError && err.code === 'P2002') {
                throw new common_1.ConflictException('You already belong to a family');
            }
            throw err;
        }
    }
    async declineInvitation(userPhone, invitationId) {
        const invitation = await this.getOwnedInvitationOrThrow(invitationId, userPhone);
        const claimed = await this.prisma.familyInvitation.updateMany({
            where: { id: invitation.id, status: client_1.InvitationStatus.PENDING },
            data: { status: client_1.InvitationStatus.DECLINED, respondedAt: new Date() },
        });
        if (claimed.count === 0)
            throw new common_1.ConflictException('This invitation is no longer pending');
        return { id: invitation.id, status: client_1.InvitationStatus.DECLINED };
    }
    async getOwnedInvitationOrThrow(invitationId, userPhone) {
        const invitation = await this.prisma.familyInvitation.findUnique({ where: { id: invitationId } });
        if (!invitation || invitation.invitedPhone !== (0, phone_util_1.normalizePhone)(userPhone)) {
            throw new common_1.NotFoundException('Invitation not found');
        }
        if (invitation.status === client_1.InvitationStatus.PENDING && invitation.expiresAt && invitation.expiresAt < new Date()) {
            await this.prisma.familyInvitation.updateMany({
                where: { id: invitation.id, status: client_1.InvitationStatus.PENDING },
                data: { status: client_1.InvitationStatus.EXPIRED },
            });
            throw new common_1.ConflictException('This invitation has expired');
        }
        if (invitation.status !== client_1.InvitationStatus.PENDING) {
            throw new common_1.ConflictException(`This invitation is already ${invitation.status.toLowerCase()}`);
        }
        return invitation;
    }
    presentSent(r) {
        return {
            id: r.id,
            familyId: r.familyId,
            invitedPhone: r.invitedPhone,
            status: r.status,
            createdAt: r.createdAt,
            expiresAt: r.expiresAt,
        };
    }
};
exports.FamilyService = FamilyService;
exports.FamilyService = FamilyService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        notifications_service_1.NotificationsService])
], FamilyService);

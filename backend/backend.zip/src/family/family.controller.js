"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FamilyController = void 0;
const common_1 = require("@nestjs/common");
const family_service_1 = require("./family.service");
const create_family_dto_1 = require("./dto/create-family.dto");
const invite_member_dto_1 = require("./dto/invite-member.dto");
const current_user_decorator_1 = require("../common/decorators/current-user.decorator");
let FamilyController = class FamilyController {
    familyService;
    constructor(familyService) {
        this.familyService = familyService;
    }
    create(userId, dto) {
        return this.familyService.createFamily(userId, dto);
    }
    getMine(userId) {
        return this.familyService.getMyFamily(userId);
    }
    listMembers(userId) {
        return this.familyService.listMembers(userId);
    }
    membersStatus(userId) {
        return this.familyService.getMembersStatusSummary(userId);
    }
    memberStatus(userId, memberUserId) {
        return this.familyService.getMemberStatus(userId, memberUserId);
    }
    invite(userId, dto) {
        return this.familyService.inviteMember(userId, dto);
    }
    listInvitations(userId, phone, type = 'incoming') {
        return type === 'sent'
            ? this.familyService.listSentInvitations(userId)
            : this.familyService.listIncomingInvitations(phone);
    }
    accept(userId, phone, invitationId) {
        return this.familyService.acceptInvitation(userId, phone, invitationId);
    }
    decline(phone, invitationId) {
        return this.familyService.declineInvitation(phone, invitationId);
    }
};
exports.FamilyController = FamilyController;
__decorate([
    (0, common_1.Post)(),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, create_family_dto_1.CreateFamilyDto]),
    __metadata("design:returntype", void 0)
], FamilyController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], FamilyController.prototype, "getMine", null);
__decorate([
    (0, common_1.Get)('members'),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], FamilyController.prototype, "listMembers", null);
__decorate([
    (0, common_1.Get)('members/status'),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], FamilyController.prototype, "membersStatus", null);
__decorate([
    (0, common_1.Get)('members/:userId/status'),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, common_1.Param)('userId', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], FamilyController.prototype, "memberStatus", null);
__decorate([
    (0, common_1.Post)('invitations'),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, invite_member_dto_1.InviteMemberDto]),
    __metadata("design:returntype", void 0)
], FamilyController.prototype, "invite", null);
__decorate([
    (0, common_1.Get)('invitations'),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)('phone')),
    __param(2, (0, common_1.Query)('type')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], FamilyController.prototype, "listInvitations", null);
__decorate([
    (0, common_1.Post)('invitations/:id/accept'),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)('phone')),
    __param(2, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], FamilyController.prototype, "accept", null);
__decorate([
    (0, common_1.Post)('invitations/:id/decline'),
    __param(0, (0, current_user_decorator_1.CurrentUser)('phone')),
    __param(1, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], FamilyController.prototype, "decline", null);
exports.FamilyController = FamilyController = __decorate([
    (0, common_1.Controller)('family'),
    __metadata("design:paramtypes", [family_service_1.FamilyService])
], FamilyController);

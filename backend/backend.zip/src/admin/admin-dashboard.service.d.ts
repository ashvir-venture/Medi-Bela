import { PrismaService } from '../prisma/prisma.service';
export declare class AdminDashboardService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    getDashboard(now?: Date): Promise<{
        generatedAt: string;
        totals: {
            users: number;
            families: number;
            prescriptions: {
                total: number;
                pending: number;
                completed: number;
                rejected: number;
            };
        };
        recentPrescriptions: {
            user: {
                name: string;
                id: string;
            };
            id: string;
            createdAt: Date;
            status: import("@prisma/client").$Enums.PrescriptionStatus;
        }[];
        analytics: {
            prescriptionsPerDay: {
                date: string;
                count: number;
            }[];
            newUsersPerDay: {
                date: string;
                count: number;
            }[];
            doses7d: {
                taken: number;
                missed: number;
                adherencePercent: number;
            };
            liveNotices: number;
            activeRules: number;
            aiSuggestionsAwaitingReview: number;
        };
    }>;
    private bucketByDay;
}

"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminDashboardService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../prisma/prisma.service");
const dose_status_util_1 = require("../medicine-schedule/lib/dose-status.util");
const time_util_1 = require("../common/utils/time.util");
const TREND_DAYS = 14;
const ADHERENCE_DAYS = 7;
const RECENT_LIMIT = 10;
let AdminDashboardService = class AdminDashboardService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async getDashboard(now = new Date()) {
        const { start: todayStart, end: todayEnd } = (0, time_util_1.appDayBounds)(now);
        const trendStart = (0, time_util_1.addAppDays)(todayStart, -(TREND_DAYS - 1));
        const adherenceStart = (0, time_util_1.addAppDays)(todayStart, -(ADHERENCE_DAYS - 1));
        const cutoff = (0, dose_status_util_1.missedCutoff)(now);
        const [users, families, pending, completed, rejected, recent, prescriptionDates, userDates, taken, missed, overduePending, liveNotices, activeRules, draftSuggestions,] = await Promise.all([
            this.prisma.user.count({ where: { role: client_1.Role.USER, accountStatus: { not: client_1.AccountStatus.DELETED } } }),
            this.prisma.family.count(),
            this.prisma.prescription.count({ where: { status: client_1.PrescriptionStatus.PENDING } }),
            this.prisma.prescription.count({ where: { status: client_1.PrescriptionStatus.COMPLETED } }),
            this.prisma.prescription.count({ where: { status: client_1.PrescriptionStatus.REJECTED } }),
            this.prisma.prescription.findMany({
                orderBy: { createdAt: 'desc' },
                take: RECENT_LIMIT,
                select: { id: true, status: true, createdAt: true, user: { select: { id: true, name: true } } },
            }),
            this.prisma.prescription.findMany({
                where: { createdAt: { gte: trendStart, lt: todayEnd } },
                select: { createdAt: true },
            }),
            this.prisma.user.findMany({
                where: { role: client_1.Role.USER, createdAt: { gte: trendStart, lt: todayEnd } },
                select: { createdAt: true },
            }),
            this.prisma.medicineDose.count({
                where: { status: client_1.DoseStatus.TAKEN, scheduledAt: { gte: adherenceStart, lt: todayEnd } },
            }),
            this.prisma.medicineDose.count({
                where: { status: client_1.DoseStatus.MISSED, scheduledAt: { gte: adherenceStart, lt: todayEnd } },
            }),
            this.prisma.medicineDose.count({
                where: { status: client_1.DoseStatus.PENDING, scheduledAt: { gte: adherenceStart, lt: cutoff } },
            }),
            this.prisma.notice.count({
                where: {
                    status: client_1.NoticeStatus.PUBLISHED,
                    OR: [{ expiresAt: null }, { expiresAt: { gt: now } }],
                },
            }),
            this.prisma.healthSuggestionRule.count({ where: { enabled: true } }),
            this.prisma.healthSuggestion.count({ where: { status: client_1.SuggestionStatus.DRAFT } }),
        ]);
        const missedTotal = missed + overduePending;
        const resolved = taken + missedTotal;
        return {
            generatedAt: now.toISOString(),
            totals: {
                users,
                families,
                prescriptions: { total: pending + completed + rejected, pending, completed, rejected },
            },
            recentPrescriptions: recent,
            analytics: {
                prescriptionsPerDay: this.bucketByDay(prescriptionDates.map((r) => r.createdAt), todayStart),
                newUsersPerDay: this.bucketByDay(userDates.map((r) => r.createdAt), todayStart),
                doses7d: {
                    taken,
                    missed: missedTotal,
                    adherencePercent: resolved === 0 ? null : Math.round((taken / resolved) * 100),
                },
                liveNotices,
                activeRules,
                aiSuggestionsAwaitingReview: draftSuggestions,
            },
        };
    }
    bucketByDay(dates, todayStart) {
        const offsetMs = (0, time_util_1.appUtcOffsetMinutes)() * 60_000;
        const days = [];
        const index = new Map();
        for (let i = TREND_DAYS - 1; i >= 0; i--) {
            const dayStart = (0, time_util_1.addAppDays)(todayStart, -i);
            const key = new Date(dayStart.getTime() + offsetMs).toISOString().slice(0, 10);
            index.set(key, days.length);
            days.push({ date: key, count: 0 });
        }
        for (const d of dates) {
            const key = new Date(d.getTime() + offsetMs).toISOString().slice(0, 10);
            const i = index.get(key);
            if (i !== undefined)
                days[i].count++;
        }
        return days;
    }
};
exports.AdminDashboardService = AdminDashboardService;
exports.AdminDashboardService = AdminDashboardService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], AdminDashboardService);

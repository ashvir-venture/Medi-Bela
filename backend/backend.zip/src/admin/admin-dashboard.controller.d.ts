import { AdminDashboardService } from './admin-dashboard.service';
export declare class AdminDashboardController {
    private readonly dashboard;
    constructor(dashboard: AdminDashboardService);
    get(): Promise<{
        generatedAt: string;
        totals: {
            users: number;
            families: number;
            prescriptions: {
                total: number;
                pending: number;
                completed: number;
                rejected: number;
            };
        };
        recentPrescriptions: {
            user: {
                name: string;
                id: string;
            };
            id: string;
            createdAt: Date;
            status: import("@prisma/client").$Enums.PrescriptionStatus;
        }[];
        analytics: {
            prescriptionsPerDay: {
                date: string;
                count: number;
            }[];
            newUsersPerDay: {
                date: string;
                count: number;
            }[];
            doses7d: {
                taken: number;
                missed: number;
                adherencePercent: number;
            };
            liveNotices: number;
            activeRules: number;
            aiSuggestionsAwaitingReview: number;
        };
    }>;
}

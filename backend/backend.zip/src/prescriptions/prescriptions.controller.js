"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrescriptionsController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const client_1 = require("@prisma/client");
const prescriptions_service_1 = require("./prescriptions.service");
const current_user_decorator_1 = require("../common/decorators/current-user.decorator");
const roles_decorator_1 = require("../common/decorators/roles.decorator");
const create_prescription_dto_1 = require("./dto/create-prescription.dto");
const save_medicines_dto_1 = require("./dto/save-medicines.dto");
const reject_prescription_dto_1 = require("./dto/reject-prescription.dto");
const prescription_image_storage_1 = require("./lib/prescription-image.storage");
let PrescriptionsController = class PrescriptionsController {
    prescriptions;
    constructor(prescriptions) {
        this.prescriptions = prescriptions;
    }
    upload(userId, image, dto) {
        if (!image) {
            throw new common_1.BadRequestException('Prescription image is required');
        }
        return this.prescriptions.create(userId, image.buffer, image.originalname, dto.clientId);
    }
    getMine(userId) {
        return this.prescriptions.getMyHistory(userId);
    }
    getOne(userId, id) {
        return this.prescriptions.getMyPrescriptionDetail(userId, id);
    }
    listPending() {
        return this.prescriptions.listPending();
    }
    getForAdmin(id) {
        return this.prescriptions.getDetailForAdmin(id);
    }
    saveMedicines(adminId, id, dto) {
        return this.prescriptions.saveMedicines(adminId, id, dto);
    }
    removeMedicine(id, medicineId) {
        return this.prescriptions.removeMedicine(id, medicineId);
    }
    complete(adminId, id) {
        return this.prescriptions.complete(adminId, id);
    }
    reject(adminId, id, dto) {
        return this.prescriptions.reject(adminId, id, dto.rejectionReason);
    }
};
exports.PrescriptionsController = PrescriptionsController;
__decorate([
    (0, common_1.Post)(),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('image', prescription_image_storage_1.prescriptionImageMulterOptions)),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, common_1.UploadedFile)()),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, create_prescription_dto_1.CreatePrescriptionDto]),
    __metadata("design:returntype", void 0)
], PrescriptionsController.prototype, "upload", null);
__decorate([
    (0, common_1.Get)('mine'),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], PrescriptionsController.prototype, "getMine", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], PrescriptionsController.prototype, "getOne", null);
__decorate([
    (0, common_1.Get)('admin/pending'),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.PHARMACIST),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], PrescriptionsController.prototype, "listPending", null);
__decorate([
    (0, common_1.Get)('admin/:id'),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.PHARMACIST),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], PrescriptionsController.prototype, "getForAdmin", null);
__decorate([
    (0, common_1.Put)('admin/:id/medicines'),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.PHARMACIST),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, save_medicines_dto_1.SaveMedicinesDto]),
    __metadata("design:returntype", void 0)
], PrescriptionsController.prototype, "saveMedicines", null);
__decorate([
    (0, common_1.Delete)('admin/:id/medicines/:medicineId'),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.PHARMACIST),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Param)('medicineId', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], PrescriptionsController.prototype, "removeMedicine", null);
__decorate([
    (0, common_1.Post)('admin/:id/complete'),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.PHARMACIST),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], PrescriptionsController.prototype, "complete", null);
__decorate([
    (0, common_1.Post)('admin/:id/reject'),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.PHARMACIST),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, reject_prescription_dto_1.RejectPrescriptionDto]),
    __metadata("design:returntype", void 0)
], PrescriptionsController.prototype, "reject", null);
exports.PrescriptionsController = PrescriptionsController = __decorate([
    (0, common_1.Controller)('prescriptions'),
    __metadata("design:paramtypes", [prescriptions_service_1.PrescriptionsService])
], PrescriptionsController);

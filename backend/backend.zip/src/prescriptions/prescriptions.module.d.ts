export declare class PrescriptionsModule {
}

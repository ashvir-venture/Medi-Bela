export declare class CreatePrescriptionDto {
    clientId?: string;
    note?: string;
}

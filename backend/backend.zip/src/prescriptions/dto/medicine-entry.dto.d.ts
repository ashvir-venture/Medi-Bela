export declare class MedicineEntryDto {
    id?: string;
    medicineName: string;
    dosage: string;
    frequency: string;
    duration: string;
    instructions?: string;
    timesPerDay?: number;
    scheduleTimes?: string[];
    durationDays?: number;
    startDate?: Date;
}

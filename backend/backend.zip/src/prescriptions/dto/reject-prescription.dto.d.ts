export declare class RejectPrescriptionDto {
    rejectionReason: string;
}

import { MedicineEntryDto } from './medicine-entry.dto';
export declare class SaveMedicinesDto {
    medicines: MedicineEntryDto[];
}

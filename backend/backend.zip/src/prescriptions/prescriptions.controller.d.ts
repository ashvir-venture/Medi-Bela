import { PrescriptionsService } from './prescriptions.service';
import { CreatePrescriptionDto } from './dto/create-prescription.dto';
import { SaveMedicinesDto } from './dto/save-medicines.dto';
import { RejectPrescriptionDto } from './dto/reject-prescription.dto';
export declare class PrescriptionsController {
    private readonly prescriptions;
    constructor(prescriptions: PrescriptionsService);
    upload(userId: string, image: Express.Multer.File | undefined, dto: CreatePrescriptionDto): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.PrescriptionStatus;
        imageUrl: string;
        reviewedById: string | null;
        reviewedAt: Date | null;
        rejectionReason: string | null;
        processingNote: string | null;
        clientUploadId: string | null;
    }>;
    getMine(userId: string): Promise<({
        medicines: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            medicineName: string;
            dosage: string;
            frequency: string;
            startDate: Date | null;
            duration: string;
            instructions: string | null;
            timesPerDay: number | null;
            scheduleTimes: string | null;
            durationDays: number | null;
            prescriptionId: string;
            verified: boolean;
            verifiedById: string | null;
            verifiedAt: Date | null;
        }[];
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.PrescriptionStatus;
        imageUrl: string;
        reviewedById: string | null;
        reviewedAt: Date | null;
        rejectionReason: string | null;
        processingNote: string | null;
        clientUploadId: string | null;
    })[]>;
    getOne(userId: string, id: string): Promise<{
        user: {
            name: string;
            id: string;
            phone: string;
            address: string;
        };
        medicines: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            medicineName: string;
            dosage: string;
            frequency: string;
            startDate: Date | null;
            duration: string;
            instructions: string | null;
            timesPerDay: number | null;
            scheduleTimes: string | null;
            durationDays: number | null;
            prescriptionId: string;
            verified: boolean;
            verifiedById: string | null;
            verifiedAt: Date | null;
        }[];
        reviewedBy: {
            name: string;
            id: string;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.PrescriptionStatus;
        imageUrl: string;
        reviewedById: string | null;
        reviewedAt: Date | null;
        rejectionReason: string | null;
        processingNote: string | null;
        clientUploadId: string | null;
    }>;
    listPending(): Promise<({
        user: {
            name: string;
            id: string;
            phone: string;
            address: string;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.PrescriptionStatus;
        imageUrl: string;
        reviewedById: string | null;
        reviewedAt: Date | null;
        rejectionReason: string | null;
        processingNote: string | null;
        clientUploadId: string | null;
    })[]>;
    getForAdmin(id: string): Promise<{
        user: {
            name: string;
            id: string;
            phone: string;
            address: string;
        };
        medicines: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            medicineName: string;
            dosage: string;
            frequency: string;
            startDate: Date | null;
            duration: string;
            instructions: string | null;
            timesPerDay: number | null;
            scheduleTimes: string | null;
            durationDays: number | null;
            prescriptionId: string;
            verified: boolean;
            verifiedById: string | null;
            verifiedAt: Date | null;
        }[];
        reviewedBy: {
            name: string;
            id: string;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.PrescriptionStatus;
        imageUrl: string;
        reviewedById: string | null;
        reviewedAt: Date | null;
        rejectionReason: string | null;
        processingNote: string | null;
        clientUploadId: string | null;
    }>;
    saveMedicines(adminId: string, id: string, dto: SaveMedicinesDto): Promise<{
        user: {
            name: string;
            id: string;
            phone: string;
            address: string;
        };
        medicines: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            medicineName: string;
            dosage: string;
            frequency: string;
            startDate: Date | null;
            duration: string;
            instructions: string | null;
            timesPerDay: number | null;
            scheduleTimes: string | null;
            durationDays: number | null;
            prescriptionId: string;
            verified: boolean;
            verifiedById: string | null;
            verifiedAt: Date | null;
        }[];
        reviewedBy: {
            name: string;
            id: string;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.PrescriptionStatus;
        imageUrl: string;
        reviewedById: string | null;
        reviewedAt: Date | null;
        rejectionReason: string | null;
        processingNote: string | null;
        clientUploadId: string | null;
    }>;
    removeMedicine(id: string, medicineId: string): Promise<{
        user: {
            name: string;
            id: string;
            phone: string;
            address: string;
        };
        medicines: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            medicineName: string;
            dosage: string;
            frequency: string;
            startDate: Date | null;
            duration: string;
            instructions: string | null;
            timesPerDay: number | null;
            scheduleTimes: string | null;
            durationDays: number | null;
            prescriptionId: string;
            verified: boolean;
            verifiedById: string | null;
            verifiedAt: Date | null;
        }[];
        reviewedBy: {
            name: string;
            id: string;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.PrescriptionStatus;
        imageUrl: string;
        reviewedById: string | null;
        reviewedAt: Date | null;
        rejectionReason: string | null;
        processingNote: string | null;
        clientUploadId: string | null;
    }>;
    complete(adminId: string, id: string): Promise<{
        user: {
            name: string;
            id: string;
            phone: string;
            address: string;
        };
        medicines: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            medicineName: string;
            dosage: string;
            frequency: string;
            startDate: Date | null;
            duration: string;
            instructions: string | null;
            timesPerDay: number | null;
            scheduleTimes: string | null;
            durationDays: number | null;
            prescriptionId: string;
            verified: boolean;
            verifiedById: string | null;
            verifiedAt: Date | null;
        }[];
        reviewedBy: {
            name: string;
            id: string;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.PrescriptionStatus;
        imageUrl: string;
        reviewedById: string | null;
        reviewedAt: Date | null;
        rejectionReason: string | null;
        processingNote: string | null;
        clientUploadId: string | null;
    }>;
    reject(adminId: string, id: string, dto: RejectPrescriptionDto): Promise<{
        user: {
            name: string;
            id: string;
            phone: string;
            address: string;
        };
        medicines: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            medicineName: string;
            dosage: string;
            frequency: string;
            startDate: Date | null;
            duration: string;
            instructions: string | null;
            timesPerDay: number | null;
            scheduleTimes: string | null;
            durationDays: number | null;
            prescriptionId: string;
            verified: boolean;
            verifiedById: string | null;
            verifiedAt: Date | null;
        }[];
        reviewedBy: {
            name: string;
            id: string;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.PrescriptionStatus;
        imageUrl: string;
        reviewedById: string | null;
        reviewedAt: Date | null;
        rejectionReason: string | null;
        processingNote: string | null;
        clientUploadId: string | null;
    }>;
}

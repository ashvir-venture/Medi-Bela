"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrescriptionsService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../prisma/prisma.service");
const routine_generation_service_1 = require("./lib/routine-generation.service");
const cloudinary_service_1 = require("./lib/cloudinary.service");
const rule_evaluation_service_1 = require("../health/rule-evaluation.service");
const health_suggestions_service_1 = require("../health/health-suggestions.service");
const notifications_service_1 = require("../notifications/notifications.service");
const notification_messages_1 = require("../notifications/notification-messages");
const SAFE_USER_SELECT = {
    id: true,
    name: true,
    phone: true,
    address: true,
};
const PRESCRIPTION_INCLUDE = {
    medicines: { orderBy: { createdAt: 'asc' } },
    user: { select: SAFE_USER_SELECT },
    reviewedBy: { select: { id: true, name: true } },
};
let PrescriptionsService = class PrescriptionsService {
    prisma;
    routineGeneration;
    ruleEvaluation;
    healthSuggestions;
    cloudinary;
    notifications;
    constructor(prisma, routineGeneration, ruleEvaluation, healthSuggestions, cloudinary, notifications) {
        this.prisma = prisma;
        this.routineGeneration = routineGeneration;
        this.ruleEvaluation = ruleEvaluation;
        this.healthSuggestions = healthSuggestions;
        this.cloudinary = cloudinary;
        this.notifications = notifications;
    }
    async create(userId, imageBuffer, originalFilename, clientId) {
        if (clientId) {
            const existing = await this.prisma.prescription.findUnique({
                where: { clientUploadId: clientId },
            });
            if (existing) {
                if (existing.userId !== userId) {
                    throw new common_1.ConflictException('clientId already in use');
                }
                return existing;
            }
        }
        const imageUrl = await this.cloudinary.uploadPrescriptionImage(imageBuffer, originalFilename);
        try {
            return await this.prisma.prescription.create({
                data: {
                    userId,
                    imageUrl,
                    clientUploadId: clientId ?? null,
                },
            });
        }
        catch (e) {
            if (clientId && this.isUniqueConstraintError(e)) {
                const existing = await this.prisma.prescription.findUnique({
                    where: { clientUploadId: clientId },
                });
                if (existing)
                    return existing;
            }
            throw e;
        }
    }
    async getMyHistory(userId) {
        return this.prisma.prescription.findMany({
            where: { userId },
            orderBy: { createdAt: 'desc' },
            include: { medicines: { orderBy: { createdAt: 'asc' } } },
        });
    }
    async getMyPrescriptionDetail(userId, id) {
        const prescription = await this.prisma.prescription.findUnique({
            where: { id },
            include: PRESCRIPTION_INCLUDE,
        });
        if (!prescription || prescription.userId !== userId) {
            throw new common_1.NotFoundException('Prescription not found');
        }
        return prescription;
    }
    async listPending() {
        return this.prisma.prescription.findMany({
            where: { status: client_1.PrescriptionStatus.PENDING },
            orderBy: { createdAt: 'asc' },
            include: { user: { select: SAFE_USER_SELECT } },
        });
    }
    async getDetailForAdmin(id) {
        const prescription = await this.prisma.prescription.findUnique({
            where: { id },
            include: PRESCRIPTION_INCLUDE,
        });
        if (!prescription) {
            throw new common_1.NotFoundException('Prescription not found');
        }
        return prescription;
    }
    async saveMedicines(adminId, prescriptionId, dto) {
        const prescription = await this.prisma.prescription.findUnique({
            where: { id: prescriptionId },
        });
        if (!prescription)
            throw new common_1.NotFoundException('Prescription not found');
        if (prescription.status !== client_1.PrescriptionStatus.PENDING) {
            throw new common_1.ConflictException(`Cannot edit medicines on a prescription that is already ${prescription.status}`);
        }
        const existingIds = new Set((await this.prisma.prescriptionMedicine.findMany({
            where: { prescriptionId },
            select: { id: true },
        })).map((m) => m.id));
        const now = new Date();
        const ops = dto.medicines.map((entry) => {
            if (entry.id) {
                if (!existingIds.has(entry.id)) {
                    throw new common_1.BadRequestException(`Medicine ${entry.id} does not belong to this prescription`);
                }
                return this.prisma.prescriptionMedicine.update({
                    where: { id: entry.id },
                    data: {
                        medicineName: entry.medicineName,
                        dosage: entry.dosage,
                        frequency: entry.frequency,
                        duration: entry.duration,
                        instructions: entry.instructions ?? null,
                        timesPerDay: entry.timesPerDay ?? null,
                        scheduleTimes: entry.scheduleTimes ? JSON.stringify(entry.scheduleTimes) : null,
                        durationDays: entry.durationDays ?? null,
                        startDate: entry.startDate ?? null,
                        verified: true,
                        verifiedById: adminId,
                        verifiedAt: now,
                    },
                });
            }
            return this.prisma.prescriptionMedicine.create({
                data: {
                    prescriptionId,
                    medicineName: entry.medicineName,
                    dosage: entry.dosage,
                    frequency: entry.frequency,
                    duration: entry.duration,
                    instructions: entry.instructions ?? null,
                    timesPerDay: entry.timesPerDay ?? null,
                    scheduleTimes: entry.scheduleTimes ? JSON.stringify(entry.scheduleTimes) : null,
                    durationDays: entry.durationDays ?? null,
                    startDate: entry.startDate ?? null,
                    verified: true,
                    verifiedById: adminId,
                    verifiedAt: now,
                },
            });
        });
        await this.prisma.$transaction(ops);
        return this.getDetailForAdmin(prescriptionId);
    }
    async removeMedicine(prescriptionId, medicineId) {
        const prescription = await this.prisma.prescription.findUnique({
            where: { id: prescriptionId },
        });
        if (!prescription)
            throw new common_1.NotFoundException('Prescription not found');
        if (prescription.status !== client_1.PrescriptionStatus.PENDING) {
            throw new common_1.ConflictException(`Cannot edit medicines on a prescription that is already ${prescription.status}`);
        }
        const medicine = await this.prisma.prescriptionMedicine.findUnique({
            where: { id: medicineId },
        });
        if (!medicine || medicine.prescriptionId !== prescriptionId) {
            throw new common_1.NotFoundException('Medicine entry not found');
        }
        await this.prisma.prescriptionMedicine.delete({ where: { id: medicineId } });
        return this.getDetailForAdmin(prescriptionId);
    }
    async complete(adminId, prescriptionId) {
        const prescription = await this.prisma.prescription.findUnique({
            where: { id: prescriptionId },
            include: { medicines: true },
        });
        if (!prescription)
            throw new common_1.NotFoundException('Prescription not found');
        if (prescription.status !== client_1.PrescriptionStatus.PENDING) {
            throw new common_1.ConflictException(`Prescription is already ${prescription.status}`);
        }
        if (prescription.medicines.length === 0) {
            throw new common_1.BadRequestException('Cannot complete a prescription with no medicines entered');
        }
        this.assertMedicinesReadyForCompletion(prescription.medicines);
        const completedAt = new Date();
        const generatedRoutines = prescription.medicines.map((m) => this.routineGeneration.generate(m, completedAt));
        await this.prisma.$transaction(async (tx) => {
            const claimed = await tx.prescription.updateMany({
                where: { id: prescriptionId, status: client_1.PrescriptionStatus.PENDING },
                data: {
                    status: client_1.PrescriptionStatus.COMPLETED,
                    reviewedById: adminId,
                    reviewedAt: completedAt,
                },
            });
            if (claimed.count === 0) {
                throw new common_1.ConflictException('Prescription is no longer pending');
            }
            for (const routine of generatedRoutines) {
                const createdRoutine = await tx.medicineRoutine.create({
                    data: {
                        userId: prescription.userId,
                        prescriptionMedicineId: routine.prescriptionMedicineId,
                        medicineName: routine.medicineName,
                        dosage: routine.dosage,
                        frequency: routine.frequency,
                        startDate: routine.startDate,
                        endDate: routine.endDate,
                        active: true,
                    },
                });
                await tx.medicineDose.createMany({
                    data: routine.doses.map((dose) => ({
                        routineId: createdRoutine.id,
                        userId: prescription.userId,
                        scheduledAt: dose.scheduledAt,
                    })),
                });
            }
        });
        for (const medicine of prescription.medicines) {
            await this.ruleEvaluation.evaluateForMedicine(prescription.userId, medicine);
        }
        await this.healthSuggestions.generateForUser(prescription.userId);
        await this.notifyOwner(prescription.userId, prescriptionId, 'COMPLETED');
        return this.getDetailForAdmin(prescriptionId);
    }
    async reject(adminId, prescriptionId, rejectionReason) {
        const prescription = await this.prisma.prescription.findUnique({
            where: { id: prescriptionId },
        });
        if (!prescription)
            throw new common_1.NotFoundException('Prescription not found');
        if (prescription.status !== client_1.PrescriptionStatus.PENDING) {
            throw new common_1.ConflictException(`Prescription is already ${prescription.status}`);
        }
        const claimed = await this.prisma.prescription.updateMany({
            where: { id: prescriptionId, status: client_1.PrescriptionStatus.PENDING },
            data: {
                status: client_1.PrescriptionStatus.REJECTED,
                reviewedById: adminId,
                reviewedAt: new Date(),
                rejectionReason,
            },
        });
        if (claimed.count === 0) {
            throw new common_1.ConflictException('Prescription is no longer pending');
        }
        await this.notifyOwner(prescription.userId, prescriptionId, 'REJECTED');
        return this.getDetailForAdmin(prescriptionId);
    }
    assertMedicinesReadyForCompletion(medicines) {
        const problems = [];
        for (const m of medicines) {
            if (!m.timesPerDay) {
                problems.push(`"${m.medicineName}": timesPerDay is required`);
                continue;
            }
            if (!m.durationDays) {
                problems.push(`"${m.medicineName}": durationDays is required`);
                continue;
            }
            let times = [];
            try {
                times = m.scheduleTimes ? JSON.parse(m.scheduleTimes) : [];
            }
            catch {
                times = [];
            }
            if (!Array.isArray(times) || times.length !== m.timesPerDay) {
                problems.push(`"${m.medicineName}": scheduleTimes must list exactly ${m.timesPerDay} time(s)`);
            }
        }
        if (problems.length > 0) {
            throw new common_1.BadRequestException({
                message: 'Cannot complete prescription: medicine schedule data is incomplete',
                details: problems,
            });
        }
    }
    async notifyOwner(userId, prescriptionId, outcome) {
        try {
            const owner = await this.prisma.user.findUnique({
                where: { id: userId },
                select: { languagePreference: true },
            });
            if (!owner)
                return;
            const copy = outcome === 'COMPLETED'
                ? notification_messages_1.messages.prescriptionCompleted(owner.languagePreference)
                : notification_messages_1.messages.prescriptionRejected(owner.languagePreference);
            await this.notifications.notify([
                {
                    userId,
                    type: client_1.NotificationType.PRESCRIPTION_UPDATE,
                    title: copy.title,
                    body: copy.body,
                    relatedEntityId: prescriptionId,
                    data: { prescriptionId },
                },
            ]);
        }
        catch {
        }
    }
    isUniqueConstraintError(e) {
        return typeof e === 'object' && e !== null && e.code === 'P2002';
    }
};
exports.PrescriptionsService = PrescriptionsService;
exports.PrescriptionsService = PrescriptionsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        routine_generation_service_1.RoutineGenerationService,
        rule_evaluation_service_1.RuleEvaluationService,
        health_suggestions_service_1.HealthSuggestionsService,
        cloudinary_service_1.CloudinaryService,
        notifications_service_1.NotificationsService])
], PrescriptionsService);

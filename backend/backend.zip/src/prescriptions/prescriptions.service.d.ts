import { PrismaService } from '../prisma/prisma.service';
import { SaveMedicinesDto } from './dto/save-medicines.dto';
import { RoutineGenerationService } from './lib/routine-generation.service';
import { CloudinaryService } from './lib/cloudinary.service';
import { RuleEvaluationService } from '../health/rule-evaluation.service';
import { HealthSuggestionsService } from '../health/health-suggestions.service';
import { NotificationsService } from '../notifications/notifications.service';
export declare class PrescriptionsService {
    private readonly prisma;
    private readonly routineGeneration;
    private readonly ruleEvaluation;
    private readonly healthSuggestions;
    private readonly cloudinary;
    private readonly notifications;
    constructor(prisma: PrismaService, routineGeneration: RoutineGenerationService, ruleEvaluation: RuleEvaluationService, healthSuggestions: HealthSuggestionsService, cloudinary: CloudinaryService, notifications: NotificationsService);
    create(userId: string, imageBuffer: Buffer, originalFilename: string, clientId?: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.PrescriptionStatus;
        imageUrl: string;
        reviewedById: string | null;
        reviewedAt: Date | null;
        rejectionReason: string | null;
        processingNote: string | null;
        clientUploadId: string | null;
    }>;
    getMyHistory(userId: string): Promise<({
        medicines: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            medicineName: string;
            dosage: string;
            frequency: string;
            startDate: Date | null;
            duration: string;
            instructions: string | null;
            timesPerDay: number | null;
            scheduleTimes: string | null;
            durationDays: number | null;
            prescriptionId: string;
            verified: boolean;
            verifiedById: string | null;
            verifiedAt: Date | null;
        }[];
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.PrescriptionStatus;
        imageUrl: string;
        reviewedById: string | null;
        reviewedAt: Date | null;
        rejectionReason: string | null;
        processingNote: string | null;
        clientUploadId: string | null;
    })[]>;
    getMyPrescriptionDetail(userId: string, id: string): Promise<{
        user: {
            name: string;
            id: string;
            phone: string;
            address: string;
        };
        medicines: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            medicineName: string;
            dosage: string;
            frequency: string;
            startDate: Date | null;
            duration: string;
            instructions: string | null;
            timesPerDay: number | null;
            scheduleTimes: string | null;
            durationDays: number | null;
            prescriptionId: string;
            verified: boolean;
            verifiedById: string | null;
            verifiedAt: Date | null;
        }[];
        reviewedBy: {
            name: string;
            id: string;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.PrescriptionStatus;
        imageUrl: string;
        reviewedById: string | null;
        reviewedAt: Date | null;
        rejectionReason: string | null;
        processingNote: string | null;
        clientUploadId: string | null;
    }>;
    listPending(): Promise<({
        user: {
            name: string;
            id: string;
            phone: string;
            address: string;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.PrescriptionStatus;
        imageUrl: string;
        reviewedById: string | null;
        reviewedAt: Date | null;
        rejectionReason: string | null;
        processingNote: string | null;
        clientUploadId: string | null;
    })[]>;
    getDetailForAdmin(id: string): Promise<{
        user: {
            name: string;
            id: string;
            phone: string;
            address: string;
        };
        medicines: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            medicineName: string;
            dosage: string;
            frequency: string;
            startDate: Date | null;
            duration: string;
            instructions: string | null;
            timesPerDay: number | null;
            scheduleTimes: string | null;
            durationDays: number | null;
            prescriptionId: string;
            verified: boolean;
            verifiedById: string | null;
            verifiedAt: Date | null;
        }[];
        reviewedBy: {
            name: string;
            id: string;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.PrescriptionStatus;
        imageUrl: string;
        reviewedById: string | null;
        reviewedAt: Date | null;
        rejectionReason: string | null;
        processingNote: string | null;
        clientUploadId: string | null;
    }>;
    saveMedicines(adminId: string, prescriptionId: string, dto: SaveMedicinesDto): Promise<{
        user: {
            name: string;
            id: string;
            phone: string;
            address: string;
        };
        medicines: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            medicineName: string;
            dosage: string;
            frequency: string;
            startDate: Date | null;
            duration: string;
            instructions: string | null;
            timesPerDay: number | null;
            scheduleTimes: string | null;
            durationDays: number | null;
            prescriptionId: string;
            verified: boolean;
            verifiedById: string | null;
            verifiedAt: Date | null;
        }[];
        reviewedBy: {
            name: string;
            id: string;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.PrescriptionStatus;
        imageUrl: string;
        reviewedById: string | null;
        reviewedAt: Date | null;
        rejectionReason: string | null;
        processingNote: string | null;
        clientUploadId: string | null;
    }>;
    removeMedicine(prescriptionId: string, medicineId: string): Promise<{
        user: {
            name: string;
            id: string;
            phone: string;
            address: string;
        };
        medicines: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            medicineName: string;
            dosage: string;
            frequency: string;
            startDate: Date | null;
            duration: string;
            instructions: string | null;
            timesPerDay: number | null;
            scheduleTimes: string | null;
            durationDays: number | null;
            prescriptionId: string;
            verified: boolean;
            verifiedById: string | null;
            verifiedAt: Date | null;
        }[];
        reviewedBy: {
            name: string;
            id: string;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.PrescriptionStatus;
        imageUrl: string;
        reviewedById: string | null;
        reviewedAt: Date | null;
        rejectionReason: string | null;
        processingNote: string | null;
        clientUploadId: string | null;
    }>;
    complete(adminId: string, prescriptionId: string): Promise<{
        user: {
            name: string;
            id: string;
            phone: string;
            address: string;
        };
        medicines: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            medicineName: string;
            dosage: string;
            frequency: string;
            startDate: Date | null;
            duration: string;
            instructions: string | null;
            timesPerDay: number | null;
            scheduleTimes: string | null;
            durationDays: number | null;
            prescriptionId: string;
            verified: boolean;
            verifiedById: string | null;
            verifiedAt: Date | null;
        }[];
        reviewedBy: {
            name: string;
            id: string;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.PrescriptionStatus;
        imageUrl: string;
        reviewedById: string | null;
        reviewedAt: Date | null;
        rejectionReason: string | null;
        processingNote: string | null;
        clientUploadId: string | null;
    }>;
    reject(adminId: string, prescriptionId: string, rejectionReason: string): Promise<{
        user: {
            name: string;
            id: string;
            phone: string;
            address: string;
        };
        medicines: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            medicineName: string;
            dosage: string;
            frequency: string;
            startDate: Date | null;
            duration: string;
            instructions: string | null;
            timesPerDay: number | null;
            scheduleTimes: string | null;
            durationDays: number | null;
            prescriptionId: string;
            verified: boolean;
            verifiedById: string | null;
            verifiedAt: Date | null;
        }[];
        reviewedBy: {
            name: string;
            id: string;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.PrescriptionStatus;
        imageUrl: string;
        reviewedById: string | null;
        reviewedAt: Date | null;
        rejectionReason: string | null;
        processingNote: string | null;
        clientUploadId: string | null;
    }>;
    private assertMedicinesReadyForCompletion;
    private notifyOwner;
    private isUniqueConstraintError;
}

import { ConfigService } from '@nestjs/config';
export declare class CloudinaryService {
    private readonly config;
    private readonly logger;
    private configured;
    constructor(config: ConfigService);
    isConfigured(): boolean;
    uploadPrescriptionImage(buffer: Buffer, originalFilename: string): Promise<string>;
}

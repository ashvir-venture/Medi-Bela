import { PrescriptionMedicine } from '@prisma/client';
export interface GeneratedDose {
    scheduledAt: Date;
}
export interface GeneratedRoutine {
    medicineName: string;
    dosage: string;
    frequency: string;
    startDate: Date;
    endDate: Date | null;
    prescriptionMedicineId: string;
    doses: GeneratedDose[];
}
export declare class RoutineGenerationService {
    generate(medicine: PrescriptionMedicine, completedAt: Date): GeneratedRoutine;
    private parseScheduleTimes;
}

import { PrismaService } from '../prisma/prisma.service';
import { AiSuggestionService } from './ai-suggestion.service';
import { UpdateHealthSuggestionDto } from './dto/update-health-suggestion.dto';
export declare class HealthSuggestionsService {
    private readonly prisma;
    private readonly aiSuggestion;
    private readonly logger;
    constructor(prisma: PrismaService, aiSuggestion: AiSuggestionService);
    generateForUser(userId: string): Promise<void>;
    listForAdmin(): Promise<({
        user: {
            name: string;
            id: string;
            phone: string;
        };
        publishedBy: {
            name: string;
            id: string;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.SuggestionStatus;
        itemsEn: import("@prisma/client/runtime/library").JsonValue;
        itemsBn: import("@prisma/client/runtime/library").JsonValue;
        sourceMedicines: string;
        publishedAt: Date | null;
        publishedById: string | null;
    })[]>;
    listForUser(userId: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.SuggestionStatus;
        itemsEn: import("@prisma/client/runtime/library").JsonValue;
        itemsBn: import("@prisma/client/runtime/library").JsonValue;
        sourceMedicines: string;
        publishedAt: Date | null;
        publishedById: string | null;
    }[]>;
    getDetail(id: string): Promise<{
        user: {
            name: string;
            id: string;
            phone: string;
        };
        publishedBy: {
            name: string;
            id: string;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.SuggestionStatus;
        itemsEn: import("@prisma/client/runtime/library").JsonValue;
        itemsBn: import("@prisma/client/runtime/library").JsonValue;
        sourceMedicines: string;
        publishedAt: Date | null;
        publishedById: string | null;
    }>;
    update(id: string, dto: UpdateHealthSuggestionDto): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.SuggestionStatus;
        itemsEn: import("@prisma/client/runtime/library").JsonValue;
        itemsBn: import("@prisma/client/runtime/library").JsonValue;
        sourceMedicines: string;
        publishedAt: Date | null;
        publishedById: string | null;
    }>;
    publish(adminId: string, id: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.SuggestionStatus;
        itemsEn: import("@prisma/client/runtime/library").JsonValue;
        itemsBn: import("@prisma/client/runtime/library").JsonValue;
        sourceMedicines: string;
        publishedAt: Date | null;
        publishedById: string | null;
    }>;
    unpublish(id: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.SuggestionStatus;
        itemsEn: import("@prisma/client/runtime/library").JsonValue;
        itemsBn: import("@prisma/client/runtime/library").JsonValue;
        sourceMedicines: string;
        publishedAt: Date | null;
        publishedById: string | null;
    }>;
    getMine(userId: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.SuggestionStatus;
        itemsEn: import("@prisma/client/runtime/library").JsonValue;
        itemsBn: import("@prisma/client/runtime/library").JsonValue;
        sourceMedicines: string;
        publishedAt: Date | null;
        publishedById: string | null;
    }[]>;
    private dedupe;
}

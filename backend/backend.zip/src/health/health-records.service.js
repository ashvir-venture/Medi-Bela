"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HealthRecordsService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../prisma/prisma.service");
let HealthRecordsService = class HealthRecordsService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(userId, dto) {
        if (dto.clientId) {
            const existing = await this.prisma.healthRecord.findUnique({
                where: { userId_clientId: { userId, clientId: dto.clientId } },
            });
            if (existing)
                return existing;
        }
        try {
            return await this.createRow(userId, dto);
        }
        catch (err) {
            if (dto.clientId && err instanceof client_1.Prisma.PrismaClientKnownRequestError && err.code === 'P2002') {
                const existing = await this.prisma.healthRecord.findUnique({
                    where: { userId_clientId: { userId, clientId: dto.clientId } },
                });
                if (existing)
                    return existing;
            }
            throw err;
        }
    }
    createRow(userId, dto) {
        return this.prisma.healthRecord.create({
            data: {
                userId,
                clientId: dto.clientId,
                type: dto.type,
                value: dto.value,
                unit: dto.unit,
                notes: dto.notes,
                recordedAt: dto.recordedAt ? new Date(dto.recordedAt) : new Date(),
            },
        });
    }
    async list(userId) {
        return this.prisma.healthRecord.findMany({
            where: { userId },
            orderBy: { recordedAt: 'desc' },
        });
    }
    async getDetail(userId, id) {
        const record = await this.prisma.healthRecord.findUnique({ where: { id } });
        if (!record || record.userId !== userId) {
            throw new common_1.NotFoundException('Health record not found');
        }
        return record;
    }
    async update(userId, id, dto) {
        await this.getDetail(userId, id);
        return this.prisma.healthRecord.update({
            where: { id },
            data: { value: dto.value, unit: dto.unit, notes: dto.notes },
        });
    }
};
exports.HealthRecordsService = HealthRecordsService;
exports.HealthRecordsService = HealthRecordsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], HealthRecordsService);

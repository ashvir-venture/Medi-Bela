import { HealthSuggestionsService } from './health-suggestions.service';
import { UpdateHealthSuggestionDto } from './dto/update-health-suggestion.dto';
export declare class HealthSuggestionsController {
    private readonly suggestions;
    constructor(suggestions: HealthSuggestionsService);
    getMine(userId: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.SuggestionStatus;
        itemsEn: import("@prisma/client/runtime/library").JsonValue;
        itemsBn: import("@prisma/client/runtime/library").JsonValue;
        sourceMedicines: string;
        publishedAt: Date | null;
        publishedById: string | null;
    }[]>;
    list(): Promise<({
        user: {
            name: string;
            id: string;
            phone: string;
        };
        publishedBy: {
            name: string;
            id: string;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.SuggestionStatus;
        itemsEn: import("@prisma/client/runtime/library").JsonValue;
        itemsBn: import("@prisma/client/runtime/library").JsonValue;
        sourceMedicines: string;
        publishedAt: Date | null;
        publishedById: string | null;
    })[]>;
    getDetail(id: string): Promise<{
        user: {
            name: string;
            id: string;
            phone: string;
        };
        publishedBy: {
            name: string;
            id: string;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.SuggestionStatus;
        itemsEn: import("@prisma/client/runtime/library").JsonValue;
        itemsBn: import("@prisma/client/runtime/library").JsonValue;
        sourceMedicines: string;
        publishedAt: Date | null;
        publishedById: string | null;
    }>;
    update(id: string, dto: UpdateHealthSuggestionDto): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.SuggestionStatus;
        itemsEn: import("@prisma/client/runtime/library").JsonValue;
        itemsBn: import("@prisma/client/runtime/library").JsonValue;
        sourceMedicines: string;
        publishedAt: Date | null;
        publishedById: string | null;
    }>;
    publish(adminId: string, id: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.SuggestionStatus;
        itemsEn: import("@prisma/client/runtime/library").JsonValue;
        itemsBn: import("@prisma/client/runtime/library").JsonValue;
        sourceMedicines: string;
        publishedAt: Date | null;
        publishedById: string | null;
    }>;
    unpublish(id: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        status: import("@prisma/client").$Enums.SuggestionStatus;
        itemsEn: import("@prisma/client/runtime/library").JsonValue;
        itemsBn: import("@prisma/client/runtime/library").JsonValue;
        sourceMedicines: string;
        publishedAt: Date | null;
        publishedById: string | null;
    }>;
}

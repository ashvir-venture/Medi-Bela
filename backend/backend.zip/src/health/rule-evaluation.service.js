"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var RuleEvaluationService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.RuleEvaluationService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma/prisma.service");
const suggestion_rule_conditions_1 = require("./lib/suggestion-rule-conditions");
let RuleEvaluationService = RuleEvaluationService_1 = class RuleEvaluationService {
    prisma;
    logger = new common_1.Logger(RuleEvaluationService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    async evaluateForMedicine(userId, medicine) {
        const enabledRules = await this.prisma.healthSuggestionRule.findMany({
            where: { enabled: true },
        });
        for (const rule of enabledRules) {
            await this.evaluateOne(rule, userId, medicine);
        }
    }
    async evaluateRuleAcrossExistingMedicines(rule) {
        const verifiedMedicines = await this.prisma.prescriptionMedicine.findMany({
            where: { verified: true, prescription: { status: 'COMPLETED' } },
            include: { prescription: { select: { userId: true } } },
        });
        let created = 0;
        for (const medicine of verifiedMedicines) {
            const didCreate = await this.evaluateOne(rule, medicine.prescription.userId, medicine);
            if (didCreate)
                created++;
        }
        this.logger.log(`Published rule ${rule.id} ("${rule.name}"): created ${created} reminder(s) across ${verifiedMedicines.length} existing verified medicine(s)`);
        return created;
    }
    async evaluateOne(rule, userId, medicine) {
        const isMatch = this.matches(rule.conditionType, rule.conditionValue, medicine);
        if (!isMatch)
            return false;
        const alreadyExists = await this.prisma.healthReminder.findFirst({
            where: { userId, sourceRuleId: rule.id },
            select: { id: true },
        });
        if (alreadyExists) {
            this.logger.debug(`Rule ${rule.id} already produced a reminder for user ${userId}; skipping`);
            return false;
        }
        await this.prisma.healthReminder.create({
            data: {
                userId,
                sourceRuleId: rule.id,
                title: rule.suggestedAction,
                description: `Suggested because you were prescribed ${medicine.medicineName}. This is not medical advice -- please consult a doctor or pharmacist.`,
                scheduledAt: new Date(),
            },
        });
        return true;
    }
    matches(conditionType, conditionValue, medicine) {
        switch (conditionType) {
            case suggestion_rule_conditions_1.CONDITION_TYPE_MEDICINE_NAME_CONTAINS:
                return conditionValue
                    .split(',')
                    .map((k) => k.trim().toLowerCase())
                    .filter(Boolean)
                    .some((keyword) => medicine.medicineName.toLowerCase().includes(keyword));
            default:
                return false;
        }
    }
};
exports.RuleEvaluationService = RuleEvaluationService;
exports.RuleEvaluationService = RuleEvaluationService = RuleEvaluationService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], RuleEvaluationService);

"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HealthRemindersService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../prisma/prisma.service");
let HealthRemindersService = class HealthRemindersService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async list(userId) {
        return this.prisma.healthReminder.findMany({
            where: { userId },
            orderBy: { scheduledAt: 'desc' },
        });
    }
    async getDetail(userId, id) {
        const reminder = await this.prisma.healthReminder.findUnique({ where: { id } });
        if (!reminder || reminder.userId !== userId) {
            throw new common_1.NotFoundException('Health reminder not found');
        }
        return reminder;
    }
    async getUpcoming(userId) {
        return this.prisma.healthReminder.findMany({
            where: { userId, status: client_1.HealthReminderStatus.PENDING, scheduledAt: { gt: new Date() } },
            orderBy: { scheduledAt: 'asc' },
        });
    }
    async getDue(userId) {
        return this.prisma.healthReminder.findMany({
            where: { userId, status: client_1.HealthReminderStatus.PENDING, scheduledAt: { lte: new Date() } },
            orderBy: { scheduledAt: 'asc' },
        });
    }
    async markComplete(userId, id, completedAt) {
        const reminder = await this.getDetail(userId, id);
        if (reminder.status === client_1.HealthReminderStatus.COMPLETED) {
            return reminder;
        }
        return this.prisma.healthReminder.update({
            where: { id },
            data: {
                status: client_1.HealthReminderStatus.COMPLETED,
                completedAt: completedAt ? new Date(completedAt) : new Date(),
            },
        });
    }
};
exports.HealthRemindersService = HealthRemindersService;
exports.HealthRemindersService = HealthRemindersService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], HealthRemindersService);

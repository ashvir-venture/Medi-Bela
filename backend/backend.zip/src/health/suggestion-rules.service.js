"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SuggestionRulesService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma/prisma.service");
const rule_evaluation_service_1 = require("./rule-evaluation.service");
let SuggestionRulesService = class SuggestionRulesService {
    prisma;
    ruleEvaluation;
    constructor(prisma, ruleEvaluation) {
        this.prisma = prisma;
        this.ruleEvaluation = ruleEvaluation;
    }
    async list() {
        return this.prisma.healthSuggestionRule.findMany({ orderBy: { createdAt: 'desc' } });
    }
    async getDetail(id) {
        const rule = await this.prisma.healthSuggestionRule.findUnique({ where: { id } });
        if (!rule)
            throw new common_1.NotFoundException('Suggestion rule not found');
        return rule;
    }
    async create(adminId, dto) {
        return this.prisma.healthSuggestionRule.create({
            data: {
                name: dto.name,
                description: dto.description,
                conditionType: dto.conditionType,
                conditionValue: dto.conditionValue,
                suggestedAction: dto.suggestedAction,
                enabled: false,
                createdById: adminId,
            },
        });
    }
    async update(id, dto) {
        await this.getDetail(id);
        return this.prisma.healthSuggestionRule.update({
            where: { id },
            data: {
                name: dto.name,
                description: dto.description,
                conditionType: dto.conditionType,
                conditionValue: dto.conditionValue,
                suggestedAction: dto.suggestedAction,
            },
        });
    }
    async publish(id) {
        const rule = await this.getDetail(id);
        const published = await this.prisma.healthSuggestionRule.update({
            where: { id },
            data: { enabled: true },
        });
        const reminderCount = await this.ruleEvaluation.evaluateRuleAcrossExistingMedicines(published);
        return { rule: published, remindersCreated: reminderCount };
    }
    async unpublish(id) {
        await this.getDetail(id);
        return this.prisma.healthSuggestionRule.update({ where: { id }, data: { enabled: false } });
    }
};
exports.SuggestionRulesService = SuggestionRulesService;
exports.SuggestionRulesService = SuggestionRulesService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        rule_evaluation_service_1.RuleEvaluationService])
], SuggestionRulesService);

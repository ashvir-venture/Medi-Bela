"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HealthRemindersController = void 0;
const common_1 = require("@nestjs/common");
const health_reminders_service_1 = require("./health-reminders.service");
const current_user_decorator_1 = require("../common/decorators/current-user.decorator");
const complete_health_reminder_dto_1 = require("./dto/complete-health-reminder.dto");
let HealthRemindersController = class HealthRemindersController {
    reminders;
    constructor(reminders) {
        this.reminders = reminders;
    }
    list(userId) {
        return this.reminders.list(userId);
    }
    getUpcoming(userId) {
        return this.reminders.getUpcoming(userId);
    }
    getDue(userId) {
        return this.reminders.getDue(userId);
    }
    getDetail(userId, id) {
        return this.reminders.getDetail(userId, id);
    }
    markComplete(userId, id, dto) {
        return this.reminders.markComplete(userId, id, dto.completedAt);
    }
};
exports.HealthRemindersController = HealthRemindersController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], HealthRemindersController.prototype, "list", null);
__decorate([
    (0, common_1.Get)('upcoming'),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], HealthRemindersController.prototype, "getUpcoming", null);
__decorate([
    (0, common_1.Get)('due'),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], HealthRemindersController.prototype, "getDue", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], HealthRemindersController.prototype, "getDetail", null);
__decorate([
    (0, common_1.Post)(':id/complete'),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, complete_health_reminder_dto_1.CompleteHealthReminderDto]),
    __metadata("design:returntype", void 0)
], HealthRemindersController.prototype, "markComplete", null);
exports.HealthRemindersController = HealthRemindersController = __decorate([
    (0, common_1.Controller)('health-reminders'),
    __metadata("design:paramtypes", [health_reminders_service_1.HealthRemindersService])
], HealthRemindersController);

import { HealthRemindersService } from './health-reminders.service';
import { CompleteHealthReminderDto } from './dto/complete-health-reminder.dto';
export declare class HealthRemindersController {
    private readonly reminders;
    constructor(reminders: HealthRemindersService);
    list(userId: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        title: string;
        scheduledAt: Date;
        status: import("@prisma/client").$Enums.HealthReminderStatus;
        description: string | null;
        sourceRuleId: string | null;
        completedAt: Date | null;
    }[]>;
    getUpcoming(userId: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        title: string;
        scheduledAt: Date;
        status: import("@prisma/client").$Enums.HealthReminderStatus;
        description: string | null;
        sourceRuleId: string | null;
        completedAt: Date | null;
    }[]>;
    getDue(userId: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        title: string;
        scheduledAt: Date;
        status: import("@prisma/client").$Enums.HealthReminderStatus;
        description: string | null;
        sourceRuleId: string | null;
        completedAt: Date | null;
    }[]>;
    getDetail(userId: string, id: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        title: string;
        scheduledAt: Date;
        status: import("@prisma/client").$Enums.HealthReminderStatus;
        description: string | null;
        sourceRuleId: string | null;
        completedAt: Date | null;
    }>;
    markComplete(userId: string, id: string, dto: CompleteHealthReminderDto): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        title: string;
        scheduledAt: Date;
        status: import("@prisma/client").$Enums.HealthReminderStatus;
        description: string | null;
        sourceRuleId: string | null;
        completedAt: Date | null;
    }>;
}

"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AiSuggestionService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AiSuggestionService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
let AiSuggestionService = class AiSuggestionService {
    static { AiSuggestionService_1 = this; }
    config;
    logger = new common_1.Logger(AiSuggestionService_1.name);
    static REQUEST_TIMEOUT_MS = 15000;
    static MAX_ITEMS_PER_LANGUAGE = 6;
    constructor(config) {
        this.config = config;
    }
    isConfigured() {
        return Boolean(this.config.get('LLM_API_BASE_URL') && this.config.get('LLM_API_KEY'));
    }
    async generate(medicines) {
        if (!this.isConfigured()) {
            this.logger.warn('AI suggestion generator used but LLM is not configured; skipping');
            return null;
        }
        if (medicines.length === 0)
            return null;
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), AiSuggestionService_1.REQUEST_TIMEOUT_MS);
        try {
            const baseUrl = this.config.get('LLM_API_BASE_URL').replace(/\/+$/, '');
            const response = await fetch(`${baseUrl}/chat/completions`, {
                method: 'POST',
                signal: controller.signal,
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${this.config.get('LLM_API_KEY')}`,
                },
                body: JSON.stringify({
                    model: this.config.get('LLM_MODEL', 'gpt-4o-mini'),
                    temperature: 0,
                    max_tokens: 700,
                    response_format: { type: 'json_object' },
                    messages: [
                        { role: 'system', content: SYSTEM_PROMPT },
                        { role: 'user', content: `Medicines: ${medicines.join(', ')}` },
                    ],
                }),
            });
            if (!response.ok) {
                this.logger.warn(`AI suggestion request failed with status ${response.status}`);
                return null;
            }
            const body = (await response.json());
            const raw = body.choices?.[0]?.message?.content?.trim() ?? '';
            return this.parse(raw);
        }
        catch (err) {
            this.logger.warn(`AI suggestion request errored: ${err.message}`);
            return null;
        }
        finally {
            clearTimeout(timeout);
        }
    }
    parse(raw) {
        try {
            const parsed = JSON.parse(raw);
            if (!parsed || typeof parsed !== 'object')
                return null;
            const en = this.parseItems(parsed.en);
            const bn = this.parseItems(parsed.bn);
            if (en.length === 0 && bn.length === 0)
                return null;
            return { en, bn };
        }
        catch (err) {
            this.logger.warn(`Failed to parse AI suggestion response as JSON: ${err.message}`);
            return null;
        }
    }
    parseItems(value) {
        if (!Array.isArray(value))
            return [];
        const items = [];
        for (const entry of value) {
            if (entry &&
                typeof entry === 'object' &&
                typeof entry.category === 'string' &&
                typeof entry.text === 'string' &&
                entry.category.trim() &&
                entry.text.trim()) {
                items.push({ category: entry.category.trim(), text: entry.text.trim() });
            }
            if (items.length >= AiSuggestionService_1.MAX_ITEMS_PER_LANGUAGE)
                break;
        }
        return items;
    }
};
exports.AiSuggestionService = AiSuggestionService;
exports.AiSuggestionService = AiSuggestionService = AiSuggestionService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], AiSuggestionService);
const SYSTEM_PROMPT = `You are a medical-information assistant embedded in a medicine-routine app. You will be given a list of a patient's current medicines (name + dosage only -- no diagnosis, no patient identity, no history).

Your task: suggest general, non-diagnostic health guidance relevant to these medicines. Suggestions can cover any relevant category -- tests to ask a doctor about, food/drink to prefer or avoid, lifestyle precautions, activities to avoid, warning signs to watch for, or anything else a pharmacist would find useful to review -- not limited to a fixed list of categories.

Rules:
- General education only. Never diagnose, never give dosing instructions, never tell the patient to start/stop/change medicine.
- Base suggestions only on well-established, general knowledge about the medicines listed.
- If a medicine is unclear or unrecognized, omit it rather than guessing.
- Output ONLY valid JSON, no markdown, no commentary, in this exact shape:
{"en":[{"category":"...","text":"..."}],"bn":[{"category":"...","text":"..."}]}
- "category" is a short free-text label you choose (e.g. "Test", "Food to avoid", "Warning sign") -- do not restrict yourself to a fixed set.
- At most 6 items per language. Keep each "text" to one short sentence.
- Bengali items must be natural Bengali, not transliteration.
- This output will be reviewed by a pharmacist/admin before any patient sees it.`;

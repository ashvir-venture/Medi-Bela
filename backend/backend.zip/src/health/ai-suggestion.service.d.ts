import { ConfigService } from '@nestjs/config';
export interface SuggestionItem {
    category: string;
    text: string;
}
export interface GeneratedSuggestions {
    en: SuggestionItem[];
    bn: SuggestionItem[];
}
export declare class AiSuggestionService {
    private readonly config;
    private readonly logger;
    private static readonly REQUEST_TIMEOUT_MS;
    private static readonly MAX_ITEMS_PER_LANGUAGE;
    constructor(config: ConfigService);
    isConfigured(): boolean;
    generate(medicines: string[]): Promise<GeneratedSuggestions | null>;
    private parse;
    private parseItems;
}

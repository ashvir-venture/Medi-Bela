"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HealthModule = void 0;
const common_1 = require("@nestjs/common");
const health_reminders_controller_1 = require("./health-reminders.controller");
const health_reminders_service_1 = require("./health-reminders.service");
const health_records_controller_1 = require("./health-records.controller");
const health_records_service_1 = require("./health-records.service");
const suggestion_rules_controller_1 = require("./suggestion-rules.controller");
const suggestion_rules_service_1 = require("./suggestion-rules.service");
const rule_evaluation_service_1 = require("./rule-evaluation.service");
const health_suggestions_controller_1 = require("./health-suggestions.controller");
const health_suggestions_service_1 = require("./health-suggestions.service");
const ai_suggestion_service_1 = require("./ai-suggestion.service");
let HealthModule = class HealthModule {
};
exports.HealthModule = HealthModule;
exports.HealthModule = HealthModule = __decorate([
    (0, common_1.Module)({
        controllers: [
            health_reminders_controller_1.HealthRemindersController,
            health_records_controller_1.HealthRecordsController,
            suggestion_rules_controller_1.SuggestionRulesController,
            health_suggestions_controller_1.HealthSuggestionsController,
        ],
        providers: [
            health_reminders_service_1.HealthRemindersService,
            health_records_service_1.HealthRecordsService,
            suggestion_rules_service_1.SuggestionRulesService,
            rule_evaluation_service_1.RuleEvaluationService,
            health_suggestions_service_1.HealthSuggestionsService,
            ai_suggestion_service_1.AiSuggestionService,
        ],
        exports: [rule_evaluation_service_1.RuleEvaluationService, health_suggestions_service_1.HealthSuggestionsService],
    })
], HealthModule);

import { HealthSuggestionRule, PrescriptionMedicine } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
export declare class RuleEvaluationService {
    private readonly prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    evaluateForMedicine(userId: string, medicine: PrescriptionMedicine): Promise<void>;
    evaluateRuleAcrossExistingMedicines(rule: HealthSuggestionRule): Promise<number>;
    private evaluateOne;
    private matches;
}

"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var HealthSuggestionsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.HealthSuggestionsService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../prisma/prisma.service");
const ai_suggestion_service_1 = require("./ai-suggestion.service");
const SAFE_USER_SELECT = { id: true, name: true, phone: true };
let HealthSuggestionsService = HealthSuggestionsService_1 = class HealthSuggestionsService {
    prisma;
    aiSuggestion;
    logger = new common_1.Logger(HealthSuggestionsService_1.name);
    constructor(prisma, aiSuggestion) {
        this.prisma = prisma;
        this.aiSuggestion = aiSuggestion;
    }
    async generateForUser(userId) {
        try {
            const verifiedMedicines = await this.prisma.prescriptionMedicine.findMany({
                where: { verified: true, prescription: { userId, status: 'COMPLETED' } },
                select: { medicineName: true, dosage: true },
            });
            if (verifiedMedicines.length === 0)
                return;
            const medicineStrings = this.dedupe(verifiedMedicines.map((m) => m.dosage ? `${m.medicineName} ${m.dosage}` : m.medicineName));
            const generated = await this.aiSuggestion.generate(medicineStrings);
            if (!generated) {
                this.logger.warn(`AI suggestion generation produced nothing for user ${userId}`);
                return;
            }
            await this.prisma.healthSuggestion.create({
                data: {
                    userId,
                    itemsEn: generated.en,
                    itemsBn: generated.bn,
                    sourceMedicines: medicineStrings.join(', '),
                    status: client_1.SuggestionStatus.DRAFT,
                },
            });
        }
        catch (err) {
            this.logger.warn(`generateForUser threw unexpectedly: ${err.message}`);
        }
    }
    async listForAdmin() {
        return this.prisma.healthSuggestion.findMany({
            orderBy: { createdAt: 'desc' },
            include: { user: { select: SAFE_USER_SELECT }, publishedBy: { select: { id: true, name: true } } },
        });
    }
    async listForUser(userId) {
        return this.prisma.healthSuggestion.findMany({
            where: { userId },
            orderBy: { createdAt: 'desc' },
        });
    }
    async getDetail(id) {
        const suggestion = await this.prisma.healthSuggestion.findUnique({
            where: { id },
            include: { user: { select: SAFE_USER_SELECT }, publishedBy: { select: { id: true, name: true } } },
        });
        if (!suggestion)
            throw new common_1.NotFoundException('Suggestion not found');
        return suggestion;
    }
    async update(id, dto) {
        await this.getDetail(id);
        return this.prisma.healthSuggestion.update({
            where: { id },
            data: { itemsEn: dto.itemsEn, itemsBn: dto.itemsBn },
        });
    }
    async publish(adminId, id) {
        await this.getDetail(id);
        return this.prisma.healthSuggestion.update({
            where: { id },
            data: { status: client_1.SuggestionStatus.PUBLISHED, publishedById: adminId, publishedAt: new Date() },
        });
    }
    async unpublish(id) {
        await this.getDetail(id);
        return this.prisma.healthSuggestion.update({
            where: { id },
            data: { status: client_1.SuggestionStatus.DRAFT, publishedById: null, publishedAt: null },
        });
    }
    async getMine(userId) {
        return this.prisma.healthSuggestion.findMany({
            where: { userId, status: client_1.SuggestionStatus.PUBLISHED },
            orderBy: { publishedAt: 'desc' },
        });
    }
    dedupe(values) {
        return [...new Set(values.map((v) => v.trim()).filter(Boolean))];
    }
};
exports.HealthSuggestionsService = HealthSuggestionsService;
exports.HealthSuggestionsService = HealthSuggestionsService = HealthSuggestionsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        ai_suggestion_service_1.AiSuggestionService])
], HealthSuggestionsService);

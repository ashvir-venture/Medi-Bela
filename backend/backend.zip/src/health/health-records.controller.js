"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HealthRecordsController = void 0;
const common_1 = require("@nestjs/common");
const health_records_service_1 = require("./health-records.service");
const current_user_decorator_1 = require("../common/decorators/current-user.decorator");
const create_health_record_dto_1 = require("./dto/create-health-record.dto");
const update_health_record_dto_1 = require("./dto/update-health-record.dto");
let HealthRecordsController = class HealthRecordsController {
    records;
    constructor(records) {
        this.records = records;
    }
    create(userId, dto) {
        return this.records.create(userId, dto);
    }
    list(userId) {
        return this.records.list(userId);
    }
    getDetail(userId, id) {
        return this.records.getDetail(userId, id);
    }
    update(userId, id, dto) {
        return this.records.update(userId, id, dto);
    }
};
exports.HealthRecordsController = HealthRecordsController;
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, create_health_record_dto_1.CreateHealthRecordDto]),
    __metadata("design:returntype", void 0)
], HealthRecordsController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], HealthRecordsController.prototype, "list", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], HealthRecordsController.prototype, "getDetail", null);
__decorate([
    (0, common_1.Patch)(':id'),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, update_health_record_dto_1.UpdateHealthRecordDto]),
    __metadata("design:returntype", void 0)
], HealthRecordsController.prototype, "update", null);
exports.HealthRecordsController = HealthRecordsController = __decorate([
    (0, common_1.Controller)('health-records'),
    __metadata("design:paramtypes", [health_records_service_1.HealthRecordsService])
], HealthRecordsController);

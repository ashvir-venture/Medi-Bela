import { PrismaService } from '../prisma/prisma.service';
export declare class HealthRemindersService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    list(userId: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        title: string;
        scheduledAt: Date;
        status: import("@prisma/client").$Enums.HealthReminderStatus;
        description: string | null;
        sourceRuleId: string | null;
        completedAt: Date | null;
    }[]>;
    getDetail(userId: string, id: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        title: string;
        scheduledAt: Date;
        status: import("@prisma/client").$Enums.HealthReminderStatus;
        description: string | null;
        sourceRuleId: string | null;
        completedAt: Date | null;
    }>;
    getUpcoming(userId: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        title: string;
        scheduledAt: Date;
        status: import("@prisma/client").$Enums.HealthReminderStatus;
        description: string | null;
        sourceRuleId: string | null;
        completedAt: Date | null;
    }[]>;
    getDue(userId: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        title: string;
        scheduledAt: Date;
        status: import("@prisma/client").$Enums.HealthReminderStatus;
        description: string | null;
        sourceRuleId: string | null;
        completedAt: Date | null;
    }[]>;
    markComplete(userId: string, id: string, completedAt?: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        userId: string;
        title: string;
        scheduledAt: Date;
        status: import("@prisma/client").$Enums.HealthReminderStatus;
        description: string | null;
        sourceRuleId: string | null;
        completedAt: Date | null;
    }>;
}

import { SuggestionRulesService } from './suggestion-rules.service';
import { CreateSuggestionRuleDto } from './dto/create-suggestion-rule.dto';
import { UpdateSuggestionRuleDto } from './dto/update-suggestion-rule.dto';
export declare class SuggestionRulesController {
    private readonly rules;
    constructor(rules: SuggestionRulesService);
    list(): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        description: string | null;
        conditionType: string;
        conditionValue: string;
        suggestedAction: string;
        enabled: boolean;
        createdById: string | null;
    }[]>;
    getDetail(id: string): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        description: string | null;
        conditionType: string;
        conditionValue: string;
        suggestedAction: string;
        enabled: boolean;
        createdById: string | null;
    }>;
    create(adminId: string, dto: CreateSuggestionRuleDto): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        description: string | null;
        conditionType: string;
        conditionValue: string;
        suggestedAction: string;
        enabled: boolean;
        createdById: string | null;
    }>;
    update(id: string, dto: UpdateSuggestionRuleDto): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        description: string | null;
        conditionType: string;
        conditionValue: string;
        suggestedAction: string;
        enabled: boolean;
        createdById: string | null;
    }>;
    publish(id: string): Promise<{
        rule: {
            name: string;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            description: string | null;
            conditionType: string;
            conditionValue: string;
            suggestedAction: string;
            enabled: boolean;
            createdById: string | null;
        };
        remindersCreated: number;
    }>;
    unpublish(id: string): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        description: string | null;
        conditionType: string;
        conditionValue: string;
        suggestedAction: string;
        enabled: boolean;
        createdById: string | null;
    }>;
}

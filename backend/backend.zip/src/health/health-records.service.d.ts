import { PrismaService } from '../prisma/prisma.service';
import { CreateHealthRecordDto } from './dto/create-health-record.dto';
import { UpdateHealthRecordDto } from './dto/update-health-record.dto';
export declare class HealthRecordsService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    create(userId: string, dto: CreateHealthRecordDto): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        value: string;
        userId: string;
        type: import("@prisma/client").$Enums.HealthRecordType;
        clientId: string | null;
        unit: string | null;
        notes: string | null;
        recordedAt: Date;
    }>;
    private createRow;
    list(userId: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        value: string;
        userId: string;
        type: import("@prisma/client").$Enums.HealthRecordType;
        clientId: string | null;
        unit: string | null;
        notes: string | null;
        recordedAt: Date;
    }[]>;
    getDetail(userId: string, id: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        value: string;
        userId: string;
        type: import("@prisma/client").$Enums.HealthRecordType;
        clientId: string | null;
        unit: string | null;
        notes: string | null;
        recordedAt: Date;
    }>;
    update(userId: string, id: string, dto: UpdateHealthRecordDto): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        value: string;
        userId: string;
        type: import("@prisma/client").$Enums.HealthRecordType;
        clientId: string | null;
        unit: string | null;
        notes: string | null;
        recordedAt: Date;
    }>;
}

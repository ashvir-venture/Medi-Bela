"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HealthSuggestionsController = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const health_suggestions_service_1 = require("./health-suggestions.service");
const current_user_decorator_1 = require("../common/decorators/current-user.decorator");
const roles_decorator_1 = require("../common/decorators/roles.decorator");
const update_health_suggestion_dto_1 = require("./dto/update-health-suggestion.dto");
let HealthSuggestionsController = class HealthSuggestionsController {
    suggestions;
    constructor(suggestions) {
        this.suggestions = suggestions;
    }
    getMine(userId) {
        return this.suggestions.getMine(userId);
    }
    list() {
        return this.suggestions.listForAdmin();
    }
    getDetail(id) {
        return this.suggestions.getDetail(id);
    }
    update(id, dto) {
        return this.suggestions.update(id, dto);
    }
    publish(adminId, id) {
        return this.suggestions.publish(adminId, id);
    }
    unpublish(id) {
        return this.suggestions.unpublish(id);
    }
};
exports.HealthSuggestionsController = HealthSuggestionsController;
__decorate([
    (0, common_1.Get)('health-suggestions/mine'),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], HealthSuggestionsController.prototype, "getMine", null);
__decorate([
    (0, common_1.Get)('admin/health-suggestions'),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.PHARMACIST),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], HealthSuggestionsController.prototype, "list", null);
__decorate([
    (0, common_1.Get)('admin/health-suggestions/:id'),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.PHARMACIST),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], HealthSuggestionsController.prototype, "getDetail", null);
__decorate([
    (0, common_1.Patch)('admin/health-suggestions/:id'),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.PHARMACIST),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_health_suggestion_dto_1.UpdateHealthSuggestionDto]),
    __metadata("design:returntype", void 0)
], HealthSuggestionsController.prototype, "update", null);
__decorate([
    (0, common_1.Post)('admin/health-suggestions/:id/publish'),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.PHARMACIST),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], HealthSuggestionsController.prototype, "publish", null);
__decorate([
    (0, common_1.Post)('admin/health-suggestions/:id/unpublish'),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.PHARMACIST),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], HealthSuggestionsController.prototype, "unpublish", null);
exports.HealthSuggestionsController = HealthSuggestionsController = __decorate([
    (0, common_1.Controller)(),
    __metadata("design:paramtypes", [health_suggestions_service_1.HealthSuggestionsService])
], HealthSuggestionsController);

"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SuggestionRulesController = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const suggestion_rules_service_1 = require("./suggestion-rules.service");
const current_user_decorator_1 = require("../common/decorators/current-user.decorator");
const roles_decorator_1 = require("../common/decorators/roles.decorator");
const create_suggestion_rule_dto_1 = require("./dto/create-suggestion-rule.dto");
const update_suggestion_rule_dto_1 = require("./dto/update-suggestion-rule.dto");
let SuggestionRulesController = class SuggestionRulesController {
    rules;
    constructor(rules) {
        this.rules = rules;
    }
    list() {
        return this.rules.list();
    }
    getDetail(id) {
        return this.rules.getDetail(id);
    }
    create(adminId, dto) {
        return this.rules.create(adminId, dto);
    }
    update(id, dto) {
        return this.rules.update(id, dto);
    }
    publish(id) {
        return this.rules.publish(id);
    }
    unpublish(id) {
        return this.rules.unpublish(id);
    }
};
exports.SuggestionRulesController = SuggestionRulesController;
__decorate([
    (0, common_1.Get)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], SuggestionRulesController.prototype, "list", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], SuggestionRulesController.prototype, "getDetail", null);
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, create_suggestion_rule_dto_1.CreateSuggestionRuleDto]),
    __metadata("design:returntype", void 0)
], SuggestionRulesController.prototype, "create", null);
__decorate([
    (0, common_1.Patch)(':id'),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_suggestion_rule_dto_1.UpdateSuggestionRuleDto]),
    __metadata("design:returntype", void 0)
], SuggestionRulesController.prototype, "update", null);
__decorate([
    (0, common_1.Post)(':id/publish'),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], SuggestionRulesController.prototype, "publish", null);
__decorate([
    (0, common_1.Post)(':id/unpublish'),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], SuggestionRulesController.prototype, "unpublish", null);
exports.SuggestionRulesController = SuggestionRulesController = __decorate([
    (0, common_1.Controller)('admin/suggestion-rules'),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.PHARMACIST),
    __metadata("design:paramtypes", [suggestion_rules_service_1.SuggestionRulesService])
], SuggestionRulesController);

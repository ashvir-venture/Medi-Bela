import { PrismaService } from '../prisma/prisma.service';
import { CreateSuggestionRuleDto } from './dto/create-suggestion-rule.dto';
import { UpdateSuggestionRuleDto } from './dto/update-suggestion-rule.dto';
import { RuleEvaluationService } from './rule-evaluation.service';
export declare class SuggestionRulesService {
    private readonly prisma;
    private readonly ruleEvaluation;
    constructor(prisma: PrismaService, ruleEvaluation: RuleEvaluationService);
    list(): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        description: string | null;
        conditionType: string;
        conditionValue: string;
        suggestedAction: string;
        enabled: boolean;
        createdById: string | null;
    }[]>;
    getDetail(id: string): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        description: string | null;
        conditionType: string;
        conditionValue: string;
        suggestedAction: string;
        enabled: boolean;
        createdById: string | null;
    }>;
    create(adminId: string, dto: CreateSuggestionRuleDto): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        description: string | null;
        conditionType: string;
        conditionValue: string;
        suggestedAction: string;
        enabled: boolean;
        createdById: string | null;
    }>;
    update(id: string, dto: UpdateSuggestionRuleDto): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        description: string | null;
        conditionType: string;
        conditionValue: string;
        suggestedAction: string;
        enabled: boolean;
        createdById: string | null;
    }>;
    publish(id: string): Promise<{
        rule: {
            name: string;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            description: string | null;
            conditionType: string;
            conditionValue: string;
            suggestedAction: string;
            enabled: boolean;
            createdById: string | null;
        };
        remindersCreated: number;
    }>;
    unpublish(id: string): Promise<{
        name: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        description: string | null;
        conditionType: string;
        conditionValue: string;
        suggestedAction: string;
        enabled: boolean;
        createdById: string | null;
    }>;
}

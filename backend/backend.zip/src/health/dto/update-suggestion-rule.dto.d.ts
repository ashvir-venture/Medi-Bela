export declare class UpdateSuggestionRuleDto {
    name?: string;
    description?: string;
    conditionType?: string;
    conditionValue?: string;
    suggestedAction?: string;
}

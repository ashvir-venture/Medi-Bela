import { HealthRecordType } from '@prisma/client';
export declare class CreateHealthRecordDto {
    type: HealthRecordType;
    value: string;
    unit?: string;
    notes?: string;
    recordedAt?: string;
    clientId?: string;
}

export declare class UpdateHealthRecordDto {
    value?: string;
    unit?: string;
    notes?: string;
}

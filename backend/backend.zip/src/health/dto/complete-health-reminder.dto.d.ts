export declare class CompleteHealthReminderDto {
    completedAt?: string;
}

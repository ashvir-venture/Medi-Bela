declare class SuggestionItemDto {
    category: string;
    text: string;
}
export declare class UpdateHealthSuggestionDto {
    itemsEn: SuggestionItemDto[];
    itemsBn: SuggestionItemDto[];
}
export {};

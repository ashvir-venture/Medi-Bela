"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoginThrottle = void 0;
const MAX_FAILURES = 8;
const WINDOW_MS = 15 * 60 * 1000;
class LoginThrottle {
    failures = new Map();
    recent(key, now) {
        const hits = (this.failures.get(key) ?? []).filter((t) => now - t < WINDOW_MS);
        if (hits.length === 0)
            this.failures.delete(key);
        else
            this.failures.set(key, hits);
        return hits;
    }
    isBlocked(key, now = Date.now()) {
        return this.recent(key, now).length >= MAX_FAILURES;
    }
    recordFailure(key, now = Date.now()) {
        const hits = this.recent(key, now);
        hits.push(now);
        this.failures.set(key, hits);
        if (this.failures.size > 10_000) {
            for (const k of this.failures.keys())
                this.recent(k, now);
        }
    }
    reset(key) {
        this.failures.delete(key);
    }
}
exports.LoginThrottle = LoginThrottle;

import { Language } from '@prisma/client';
export declare class RegisterDto {
    phone: string;
    name: string;
    address?: string;
    password: string;
    languagePreference?: Language;
}

import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../prisma/prisma.service';
import { SafeUser } from '../common/utils/sanitize-user';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';
import { ChangePasswordDto } from './dto/change-password.dto';
import { TokenPair } from './types/tokens.type';
export declare class AuthService {
    private readonly prisma;
    private readonly jwt;
    private readonly config;
    private readonly throttle;
    constructor(prisma: PrismaService, jwt: JwtService, config: ConfigService);
    register(dto: RegisterDto): Promise<{
        user: SafeUser;
        tokens: TokenPair;
    }>;
    login(dto: LoginDto, clientIp?: string): Promise<{
        user: SafeUser;
        tokens: TokenPair;
    }>;
    logout(_userId: string): Promise<void>;
    changePassword(userId: string, dto: ChangePasswordDto): Promise<void>;
    private issueTokens;
}

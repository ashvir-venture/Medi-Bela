export declare class LoginThrottle {
    private readonly failures;
    private recent;
    isBlocked(key: string, now?: number): boolean;
    recordFailure(key: string, now?: number): void;
    reset(key: string): void;
}

import type { Request } from 'express';
import { AuthService } from './auth.service';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';
import { ChangePasswordDto } from './dto/change-password.dto';
export declare class AuthController {
    private readonly authService;
    constructor(authService: AuthService);
    register(dto: RegisterDto): Promise<{
        user: import("../common/utils/sanitize-user").SafeUser;
        tokens: import("./types/tokens.type").TokenPair;
    }>;
    login(dto: LoginDto, req: Request): Promise<{
        user: import("../common/utils/sanitize-user").SafeUser;
        tokens: import("./types/tokens.type").TokenPair;
    }>;
    logout(userId: string): Promise<void>;
    changePassword(userId: string, dto: ChangePasswordDto): Promise<void>;
}

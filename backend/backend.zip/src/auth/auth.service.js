"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const jwt_1 = require("@nestjs/jwt");
const client_1 = require("@prisma/client");
const argon2 = __importStar(require("argon2"));
const prisma_service_1 = require("../prisma/prisma.service");
const sanitize_user_1 = require("../common/utils/sanitize-user");
const login_throttle_1 = require("./login-throttle");
const DUMMY_HASH_PROMISE = argon2.hash('carebridge-dummy-password');
let AuthService = class AuthService {
    prisma;
    jwt;
    config;
    throttle = new login_throttle_1.LoginThrottle();
    constructor(prisma, jwt, config) {
        this.prisma = prisma;
        this.jwt = jwt;
        this.config = config;
    }
    async register(dto) {
        const passwordHash = await argon2.hash(dto.password);
        let user;
        try {
            user = await this.prisma.user.create({
                data: {
                    phone: dto.phone,
                    name: dto.name,
                    address: dto.address,
                    passwordHash,
                    languagePreference: dto.languagePreference,
                },
            });
        }
        catch (err) {
            if (err instanceof client_1.Prisma.PrismaClientKnownRequestError &&
                err.code === 'P2002') {
                throw new common_1.ConflictException('Phone number is already registered');
            }
            throw err;
        }
        const tokens = await this.issueTokens(user);
        return { user: (0, sanitize_user_1.sanitizeUser)(user), tokens };
    }
    async login(dto, clientIp = 'unknown') {
        const throttleKey = `${clientIp}|${dto.phone}`;
        if (this.throttle.isBlocked(throttleKey)) {
            throw new common_1.HttpException('Too many failed login attempts. Please try again in a few minutes.', common_1.HttpStatus.TOO_MANY_REQUESTS);
        }
        const user = await this.prisma.user.findUnique({
            where: { phone: dto.phone },
        });
        const passwordMatches = await argon2.verify(user ? user.passwordHash : await DUMMY_HASH_PROMISE, dto.password);
        if (!user || !passwordMatches) {
            this.throttle.recordFailure(throttleKey);
            throw new common_1.UnauthorizedException('Invalid phone number or password');
        }
        if (user.accountStatus !== 'ACTIVE') {
            throw new common_1.ForbiddenException('Account is not active');
        }
        this.throttle.reset(throttleKey);
        const tokens = await this.issueTokens(user);
        return { user: (0, sanitize_user_1.sanitizeUser)(user), tokens };
    }
    async logout(_userId) {
        return;
    }
    async changePassword(userId, dto) {
        const user = await this.prisma.user.findUnique({ where: { id: userId } });
        if (!user) {
            throw new common_1.UnauthorizedException();
        }
        const currentMatches = await argon2.verify(user.passwordHash, dto.currentPassword);
        if (!currentMatches) {
            throw new common_1.UnauthorizedException('Current password is incorrect');
        }
        const newPasswordHash = await argon2.hash(dto.newPassword);
        await this.prisma.user.update({
            where: { id: userId },
            data: { passwordHash: newPasswordHash },
        });
    }
    async issueTokens(user) {
        const payload = {
            sub: user.id,
            phone: user.phone,
            role: user.role,
        };
        const accessToken = await this.jwt.signAsync(payload, {
            secret: this.config.getOrThrow('JWT_ACCESS_SECRET'),
            expiresIn: this.config.get('JWT_ACCESS_EXPIRES_IN', '30d'),
        });
        return { accessToken };
    }
};
exports.AuthService = AuthService;
exports.AuthService = AuthService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        jwt_1.JwtService,
        config_1.ConfigService])
], AuthService);

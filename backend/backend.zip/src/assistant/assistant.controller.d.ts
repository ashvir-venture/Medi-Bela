import { AssistantService } from './assistant.service';
import { ChatDto } from './dto/chat.dto';
export declare class AssistantController {
    private readonly assistant;
    constructor(assistant: AssistantService);
    chat(userId: string, dto: ChatDto): Promise<import("./assistant.service").AssistantResponse>;
}

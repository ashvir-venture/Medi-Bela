export declare class AssistantModule {
}

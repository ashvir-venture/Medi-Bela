"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var LlmProvider_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.LlmProvider = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
let LlmProvider = class LlmProvider {
    static { LlmProvider_1 = this; }
    config;
    logger = new common_1.Logger(LlmProvider_1.name);
    static TIMEOUT_MS = 20_000;
    constructor(config) {
        this.config = config;
    }
    isConfigured() {
        return Boolean(this.config.get('LLM_API_BASE_URL') && this.config.get('LLM_API_KEY'));
    }
    async complete(system, turns) {
        if (!this.isConfigured())
            return null;
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), LlmProvider_1.TIMEOUT_MS);
        try {
            const baseUrl = this.config.get('LLM_API_BASE_URL').replace(/\/+$/, '');
            const response = await fetch(`${baseUrl}/chat/completions`, {
                method: 'POST',
                signal: controller.signal,
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${this.config.get('LLM_API_KEY')}`,
                },
                body: JSON.stringify({
                    model: this.config.get('LLM_MODEL', 'gpt-4o-mini'),
                    temperature: 0.2,
                    max_tokens: 450,
                    messages: [{ role: 'system', content: system }, ...turns],
                }),
            });
            if (!response.ok) {
                this.logger.warn(`AI provider responded ${response.status}`);
                return null;
            }
            const body = (await response.json());
            return body.choices?.[0]?.message?.content?.trim() || null;
        }
        catch (err) {
            this.logger.warn(`AI provider call failed: ${err.name}`);
            return null;
        }
        finally {
            clearTimeout(timer);
        }
    }
};
exports.LlmProvider = LlmProvider;
exports.LlmProvider = LlmProvider = LlmProvider_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], LlmProvider);

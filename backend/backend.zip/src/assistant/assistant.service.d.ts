import { PrismaService } from '../prisma/prisma.service';
import { AssistantReplyKind } from './assistant-safety';
import { ChatDto } from './dto/chat.dto';
import { LlmProvider } from './llm.provider';
export interface AssistantResponse {
    reply: string;
    kind: AssistantReplyKind;
    disclaimer: string;
}
export declare class AssistantService {
    private readonly prisma;
    private readonly llm;
    private readonly recent;
    constructor(prisma: PrismaService, llm: LlmProvider);
    chat(userId: string, dto: ChatDto, now?: number): Promise<AssistantResponse>;
    private languageOf;
    private loadContext;
    private enforceRateLimit;
}

import { Language } from '@prisma/client';
export type AssistantReplyKind = 'ANSWER' | 'EMERGENCY' | 'REFUSAL';
export type RestrictedIntent = 'DOSE_CHANGE' | 'PRESCRIBE' | 'DIAGNOSE' | 'TREATMENT_PLAN' | 'MODIFY_ROUTINE';
export declare function detectEmergency(text: string): boolean;
export declare function detectRestrictedIntent(text: string): RestrictedIntent | null;
export declare function disclaimerFor(lang: Language): string;
export declare function emergencyReply(lang: Language): string;
export declare function refusalReply(intent: RestrictedIntent, lang: Language): string;
export interface AssistantContext {
    routines: Array<{
        medicine: string;
        dosage: string;
        frequency: string;
        instructions: string | null;
    }>;
    reminders: Array<{
        title: string;
        when: string;
    }>;
}
export declare function clean(value: string | null | undefined, max?: number): string;
export declare function buildSystemPrompt(lang: Language, context: AssistantContext): string;

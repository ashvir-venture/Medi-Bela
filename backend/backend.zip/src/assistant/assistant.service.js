"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AssistantService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../prisma/prisma.service");
const assistant_safety_1 = require("./assistant-safety");
const llm_provider_1 = require("./llm.provider");
const MAX_MESSAGES_PER_HOUR = 20;
const WINDOW_MS = 60 * 60 * 1000;
const MAX_HISTORY_TURNS = 6;
const MAX_REPLY_CHARS = 1500;
let AssistantService = class AssistantService {
    prisma;
    llm;
    recent = new Map();
    constructor(prisma, llm) {
        this.prisma = prisma;
        this.llm = llm;
    }
    async chat(userId, dto, now = Date.now()) {
        this.enforceRateLimit(userId, now);
        const lang = dto.language ?? (await this.languageOf(userId));
        const message = dto.message.trim();
        const disclaimer = (0, assistant_safety_1.disclaimerFor)(lang);
        const userTexts = [message, ...(dto.history ?? []).filter((t) => t.role === 'user').map((t) => t.content)];
        if (userTexts.some(assistant_safety_1.detectEmergency)) {
            return { reply: (0, assistant_safety_1.emergencyReply)(lang), kind: 'EMERGENCY', disclaimer };
        }
        const intent = (0, assistant_safety_1.detectRestrictedIntent)(message);
        if (intent) {
            return { reply: (0, assistant_safety_1.refusalReply)(intent, lang), kind: 'REFUSAL', disclaimer };
        }
        if (!this.llm.isConfigured())
            throw new common_1.ServiceUnavailableException('The assistant is currently unavailable');
        const context = await this.loadContext(userId);
        const turns = [
            ...(dto.history ?? []).slice(-MAX_HISTORY_TURNS).map((t) => ({ role: t.role, content: t.content })),
            { role: 'user', content: message },
        ];
        const text = await this.llm.complete((0, assistant_safety_1.buildSystemPrompt)(lang, context), turns);
        if (!text)
            throw new common_1.ServiceUnavailableException('The assistant is currently unavailable');
        return { reply: text.slice(0, MAX_REPLY_CHARS), kind: 'ANSWER', disclaimer };
    }
    async languageOf(userId) {
        const user = await this.prisma.user.findUnique({ where: { id: userId }, select: { languagePreference: true } });
        return user?.languagePreference ?? client_1.Language.EN;
    }
    async loadContext(userId) {
        const [routines, reminders] = await Promise.all([
            this.prisma.medicineRoutine.findMany({
                where: { userId, active: true },
                orderBy: { createdAt: 'desc' },
                take: 10,
                select: {
                    medicineName: true,
                    dosage: true,
                    frequency: true,
                    prescriptionMedicine: { select: { instructions: true } },
                },
            }),
            this.prisma.healthReminder.findMany({
                where: { userId, status: 'PENDING' },
                orderBy: { scheduledAt: 'asc' },
                take: 10,
                select: { title: true, scheduledAt: true },
            }),
        ]);
        return {
            routines: routines.map((r) => ({
                medicine: (0, assistant_safety_1.clean)(r.medicineName, 80),
                dosage: (0, assistant_safety_1.clean)(r.dosage, 40),
                frequency: (0, assistant_safety_1.clean)(r.frequency, 60),
                instructions: r.prescriptionMedicine?.instructions ? (0, assistant_safety_1.clean)(r.prescriptionMedicine.instructions, 160) : null,
            })),
            reminders: reminders.map((r) => ({
                title: (0, assistant_safety_1.clean)(r.title, 120),
                when: new Date(r.scheduledAt).toISOString().slice(0, 10),
            })),
        };
    }
    enforceRateLimit(userId, now) {
        const hits = (this.recent.get(userId) ?? []).filter((t) => now - t < WINDOW_MS);
        if (hits.length >= MAX_MESSAGES_PER_HOUR) {
            this.recent.set(userId, hits);
            throw new common_1.HttpException('Too many assistant messages. Please try again later.', common_1.HttpStatus.TOO_MANY_REQUESTS);
        }
        hits.push(now);
        this.recent.set(userId, hits);
    }
};
exports.AssistantService = AssistantService;
exports.AssistantService = AssistantService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        llm_provider_1.LlmProvider])
], AssistantService);

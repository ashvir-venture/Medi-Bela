import { Language } from '@prisma/client';
export declare class ChatTurnDto {
    role: 'user' | 'assistant';
    content: string;
}
export declare class ChatDto {
    message: string;
    history?: ChatTurnDto[];
    language?: Language;
}

import { ConfigService } from '@nestjs/config';
export interface ChatTurn {
    role: 'user' | 'assistant';
    content: string;
}
export declare class LlmProvider {
    private readonly config;
    private readonly logger;
    private static readonly TIMEOUT_MS;
    constructor(config: ConfigService);
    isConfigured(): boolean;
    complete(system: string, turns: ChatTurn[]): Promise<string | null>;
}

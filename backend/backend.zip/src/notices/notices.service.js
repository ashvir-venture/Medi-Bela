"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NoticesService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../prisma/prisma.service");
const notifications_service_1 = require("../notifications/notifications.service");
const notification_messages_1 = require("../notifications/notification-messages");
let NoticesService = class NoticesService {
    prisma;
    notifications;
    constructor(prisma, notifications) {
        this.prisma = prisma;
        this.notifications = notifications;
    }
    async listForAdmin() {
        return this.prisma.notice.findMany({
            orderBy: { createdAt: 'desc' },
            include: { createdBy: { select: { id: true, name: true } } },
        });
    }
    async getDetail(id) {
        const notice = await this.prisma.notice.findUnique({
            where: { id },
            include: { createdBy: { select: { id: true, name: true } } },
        });
        if (!notice)
            throw new common_1.NotFoundException('Notice not found');
        return notice;
    }
    async create(adminId, dto) {
        return this.prisma.notice.create({
            data: {
                title: dto.title,
                content: dto.content,
                audience: dto.audience,
                expiresAt: dto.expiresAt ? new Date(dto.expiresAt) : null,
                status: client_1.NoticeStatus.DRAFT,
                createdById: adminId,
            },
        });
    }
    async update(id, dto) {
        await this.getDetail(id);
        return this.prisma.notice.update({
            where: { id },
            data: {
                title: dto.title,
                content: dto.content,
                audience: dto.audience,
                expiresAt: dto.expiresAt === null ? null : dto.expiresAt ? new Date(dto.expiresAt) : undefined,
            },
        });
    }
    async publish(id) {
        const notice = await this.getDetail(id);
        if (notice.status === client_1.NoticeStatus.PUBLISHED)
            return notice;
        if (notice.status === client_1.NoticeStatus.ARCHIVED) {
            return this.prisma.notice.update({ where: { id }, data: { status: client_1.NoticeStatus.PUBLISHED } });
        }
        const claimed = await this.prisma.notice.updateMany({
            where: { id, status: client_1.NoticeStatus.DRAFT },
            data: { status: client_1.NoticeStatus.PUBLISHED, publishedAt: new Date() },
        });
        const published = await this.getDetail(id);
        const alreadyExpired = published.expiresAt !== null && published.expiresAt <= new Date();
        if (claimed.count === 1 && !alreadyExpired) {
            await this.pushToAudience(published);
        }
        return published;
    }
    async pushToAudience(notice) {
        const roles = notice.audience === client_1.NoticeAudience.USER
            ? [client_1.Role.USER]
            : notice.audience === client_1.NoticeAudience.ADMIN
                ? [client_1.Role.ADMIN, client_1.Role.PHARMACIST]
                : [client_1.Role.USER, client_1.Role.ADMIN, client_1.Role.PHARMACIST];
        const recipients = await this.prisma.user.findMany({
            where: { accountStatus: client_1.AccountStatus.ACTIVE, role: { in: roles } },
            select: { id: true },
        });
        const copy = notification_messages_1.messages.notice(notice.title, notice.content);
        await this.notifications.notify(recipients.map((r) => ({
            userId: r.id,
            type: client_1.NotificationType.NOTICE,
            title: copy.title,
            body: copy.body,
            relatedEntityId: notice.id,
            data: { noticeId: notice.id },
        })));
    }
    async archive(id) {
        await this.getDetail(id);
        return this.prisma.notice.update({ where: { id }, data: { status: client_1.NoticeStatus.ARCHIVED } });
    }
    async remove(id) {
        await this.getDetail(id);
        await this.prisma.notice.delete({ where: { id } });
    }
    async listVisibleTo(role) {
        const now = new Date();
        return this.prisma.notice.findMany({
            where: {
                status: client_1.NoticeStatus.PUBLISHED,
                OR: [{ expiresAt: null }, { expiresAt: { gt: now } }],
                audience: { in: ['ALL', role === client_1.Role.ADMIN || role === client_1.Role.PHARMACIST ? 'ADMIN' : 'USER'] },
            },
            orderBy: { publishedAt: 'desc' },
        });
    }
};
exports.NoticesService = NoticesService;
exports.NoticesService = NoticesService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        notifications_service_1.NotificationsService])
], NoticesService);

import { NoticeAudience } from '@prisma/client';
export declare class UpdateNoticeDto {
    title?: string;
    content?: string;
    audience?: NoticeAudience;
    expiresAt?: string | null;
}

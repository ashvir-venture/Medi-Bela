import { NoticeAudience } from '@prisma/client';
export declare class CreateNoticeDto {
    title: string;
    content: string;
    audience?: NoticeAudience;
    expiresAt?: string;
}

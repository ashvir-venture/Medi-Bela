import { Role } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { NotificationsService } from '../notifications/notifications.service';
import { CreateNoticeDto } from './dto/create-notice.dto';
import { UpdateNoticeDto } from './dto/update-notice.dto';
export declare class NoticesService {
    private readonly prisma;
    private readonly notifications;
    constructor(prisma: PrismaService, notifications: NotificationsService);
    listForAdmin(): Promise<({
        createdBy: {
            name: string;
            id: string;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        audience: import("@prisma/client").$Enums.NoticeAudience;
        title: string;
        status: import("@prisma/client").$Enums.NoticeStatus;
        expiresAt: Date | null;
        createdById: string | null;
        publishedAt: Date | null;
        content: string;
    })[]>;
    getDetail(id: string): Promise<{
        createdBy: {
            name: string;
            id: string;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        audience: import("@prisma/client").$Enums.NoticeAudience;
        title: string;
        status: import("@prisma/client").$Enums.NoticeStatus;
        expiresAt: Date | null;
        createdById: string | null;
        publishedAt: Date | null;
        content: string;
    }>;
    create(adminId: string, dto: CreateNoticeDto): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        audience: import("@prisma/client").$Enums.NoticeAudience;
        title: string;
        status: import("@prisma/client").$Enums.NoticeStatus;
        expiresAt: Date | null;
        createdById: string | null;
        publishedAt: Date | null;
        content: string;
    }>;
    update(id: string, dto: UpdateNoticeDto): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        audience: import("@prisma/client").$Enums.NoticeAudience;
        title: string;
        status: import("@prisma/client").$Enums.NoticeStatus;
        expiresAt: Date | null;
        createdById: string | null;
        publishedAt: Date | null;
        content: string;
    }>;
    publish(id: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        audience: import("@prisma/client").$Enums.NoticeAudience;
        title: string;
        status: import("@prisma/client").$Enums.NoticeStatus;
        expiresAt: Date | null;
        createdById: string | null;
        publishedAt: Date | null;
        content: string;
    }>;
    private pushToAudience;
    archive(id: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        audience: import("@prisma/client").$Enums.NoticeAudience;
        title: string;
        status: import("@prisma/client").$Enums.NoticeStatus;
        expiresAt: Date | null;
        createdById: string | null;
        publishedAt: Date | null;
        content: string;
    }>;
    remove(id: string): Promise<void>;
    listVisibleTo(role: Role): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        audience: import("@prisma/client").$Enums.NoticeAudience;
        title: string;
        status: import("@prisma/client").$Enums.NoticeStatus;
        expiresAt: Date | null;
        createdById: string | null;
        publishedAt: Date | null;
        content: string;
    }[]>;
}

"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NoticesController = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const notices_service_1 = require("./notices.service");
const current_user_decorator_1 = require("../common/decorators/current-user.decorator");
const roles_decorator_1 = require("../common/decorators/roles.decorator");
const create_notice_dto_1 = require("./dto/create-notice.dto");
const update_notice_dto_1 = require("./dto/update-notice.dto");
let NoticesController = class NoticesController {
    notices;
    constructor(notices) {
        this.notices = notices;
    }
    listMine(role) {
        return this.notices.listVisibleTo(role);
    }
    list() {
        return this.notices.listForAdmin();
    }
    getDetail(id) {
        return this.notices.getDetail(id);
    }
    create(adminId, dto) {
        return this.notices.create(adminId, dto);
    }
    update(id, dto) {
        return this.notices.update(id, dto);
    }
    publish(id) {
        return this.notices.publish(id);
    }
    archive(id) {
        return this.notices.archive(id);
    }
    remove(id) {
        return this.notices.remove(id);
    }
};
exports.NoticesController = NoticesController;
__decorate([
    (0, common_1.Get)('notices/mine'),
    __param(0, (0, current_user_decorator_1.CurrentUser)('role')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], NoticesController.prototype, "listMine", null);
__decorate([
    (0, common_1.Get)('admin/notices'),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.PHARMACIST),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], NoticesController.prototype, "list", null);
__decorate([
    (0, common_1.Get)('admin/notices/:id'),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.PHARMACIST),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], NoticesController.prototype, "getDetail", null);
__decorate([
    (0, common_1.Post)('admin/notices'),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.PHARMACIST),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, create_notice_dto_1.CreateNoticeDto]),
    __metadata("design:returntype", void 0)
], NoticesController.prototype, "create", null);
__decorate([
    (0, common_1.Patch)('admin/notices/:id'),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.PHARMACIST),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_notice_dto_1.UpdateNoticeDto]),
    __metadata("design:returntype", void 0)
], NoticesController.prototype, "update", null);
__decorate([
    (0, common_1.Post)('admin/notices/:id/publish'),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.PHARMACIST),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], NoticesController.prototype, "publish", null);
__decorate([
    (0, common_1.Post)('admin/notices/:id/archive'),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.PHARMACIST),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], NoticesController.prototype, "archive", null);
__decorate([
    (0, common_1.Delete)('admin/notices/:id'),
    (0, roles_decorator_1.Roles)(client_1.Role.ADMIN, client_1.Role.PHARMACIST),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], NoticesController.prototype, "remove", null);
exports.NoticesController = NoticesController = __decorate([
    (0, common_1.Controller)(),
    __metadata("design:paramtypes", [notices_service_1.NoticesService])
], NoticesController);

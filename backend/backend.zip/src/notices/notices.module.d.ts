export declare class NoticesModule {
}

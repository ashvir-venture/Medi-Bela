import { Role } from '@prisma/client';
import { NoticesService } from './notices.service';
import { CreateNoticeDto } from './dto/create-notice.dto';
import { UpdateNoticeDto } from './dto/update-notice.dto';
export declare class NoticesController {
    private readonly notices;
    constructor(notices: NoticesService);
    listMine(role: Role): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        audience: import("@prisma/client").$Enums.NoticeAudience;
        title: string;
        status: import("@prisma/client").$Enums.NoticeStatus;
        expiresAt: Date | null;
        createdById: string | null;
        publishedAt: Date | null;
        content: string;
    }[]>;
    list(): Promise<({
        createdBy: {
            name: string;
            id: string;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        audience: import("@prisma/client").$Enums.NoticeAudience;
        title: string;
        status: import("@prisma/client").$Enums.NoticeStatus;
        expiresAt: Date | null;
        createdById: string | null;
        publishedAt: Date | null;
        content: string;
    })[]>;
    getDetail(id: string): Promise<{
        createdBy: {
            name: string;
            id: string;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        audience: import("@prisma/client").$Enums.NoticeAudience;
        title: string;
        status: import("@prisma/client").$Enums.NoticeStatus;
        expiresAt: Date | null;
        createdById: string | null;
        publishedAt: Date | null;
        content: string;
    }>;
    create(adminId: string, dto: CreateNoticeDto): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        audience: import("@prisma/client").$Enums.NoticeAudience;
        title: string;
        status: import("@prisma/client").$Enums.NoticeStatus;
        expiresAt: Date | null;
        createdById: string | null;
        publishedAt: Date | null;
        content: string;
    }>;
    update(id: string, dto: UpdateNoticeDto): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        audience: import("@prisma/client").$Enums.NoticeAudience;
        title: string;
        status: import("@prisma/client").$Enums.NoticeStatus;
        expiresAt: Date | null;
        createdById: string | null;
        publishedAt: Date | null;
        content: string;
    }>;
    publish(id: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        audience: import("@prisma/client").$Enums.NoticeAudience;
        title: string;
        status: import("@prisma/client").$Enums.NoticeStatus;
        expiresAt: Date | null;
        createdById: string | null;
        publishedAt: Date | null;
        content: string;
    }>;
    archive(id: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        audience: import("@prisma/client").$Enums.NoticeAudience;
        title: string;
        status: import("@prisma/client").$Enums.NoticeStatus;
        expiresAt: Date | null;
        createdById: string | null;
        publishedAt: Date | null;
        content: string;
    }>;
    remove(id: string): Promise<void>;
}

import { Role } from '@prisma/client';
export interface JwtPayload {
    sub: string;
    phone: string;
    role: Role;
}
export interface AuthenticatedUser {
    id: string;
    phone: string;
    role: Role;
}

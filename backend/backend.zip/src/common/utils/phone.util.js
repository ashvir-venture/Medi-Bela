"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.normalizePhone = normalizePhone;
function normalizePhone(raw) {
    let value = raw.trim().replace(/[\s\-().]/g, '');
    if (value.startsWith('00'))
        value = `+${value.slice(2)}`;
    if (/^01\d{9}$/.test(value))
        return `+88${value}`;
    if (!value.startsWith('+'))
        value = `+${value}`;
    return value;
}

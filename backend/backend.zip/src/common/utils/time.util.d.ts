export declare function appUtcOffsetMinutes(): number;
export declare function startOfAppDay(ref: Date, offsetMinutes?: number): Date;
export declare function appDayBounds(ref: Date, offsetMinutes?: number): {
    start: Date;
    end: Date;
};
export declare function addAppDays(dayStart: Date, days: number): Date;
export declare function atAppTime(dayStart: Date, hhmm: string): Date;

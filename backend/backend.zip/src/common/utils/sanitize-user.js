"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sanitizeUser = sanitizeUser;
function sanitizeUser(user) {
    const { passwordHash, ...safeUser } = user;
    return safeUser;
}

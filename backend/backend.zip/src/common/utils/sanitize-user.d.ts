import { User } from '@prisma/client';
export type SafeUser = Omit<User, 'passwordHash'>;
export declare function sanitizeUser(user: User): SafeUser;

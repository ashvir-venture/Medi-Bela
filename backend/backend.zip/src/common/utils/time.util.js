"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.appUtcOffsetMinutes = appUtcOffsetMinutes;
exports.startOfAppDay = startOfAppDay;
exports.appDayBounds = appDayBounds;
exports.addAppDays = addAppDays;
exports.atAppTime = atAppTime;
const DEFAULT_OFFSET_MINUTES = 360;
const MINUTE_MS = 60_000;
const DAY_MS = 24 * 60 * MINUTE_MS;
function appUtcOffsetMinutes() {
    const raw = process.env.APP_UTC_OFFSET_MINUTES;
    const parsed = raw === undefined || raw === '' ? NaN : Number(raw);
    return Number.isFinite(parsed) ? parsed : DEFAULT_OFFSET_MINUTES;
}
function startOfAppDay(ref, offsetMinutes = appUtcOffsetMinutes()) {
    const shifted = ref.getTime() + offsetMinutes * MINUTE_MS;
    const localMidnightAsUtc = Math.floor(shifted / DAY_MS) * DAY_MS;
    return new Date(localMidnightAsUtc - offsetMinutes * MINUTE_MS);
}
function appDayBounds(ref, offsetMinutes = appUtcOffsetMinutes()) {
    const start = startOfAppDay(ref, offsetMinutes);
    return { start, end: new Date(start.getTime() + DAY_MS) };
}
function addAppDays(dayStart, days) {
    return new Date(dayStart.getTime() + days * DAY_MS);
}
function atAppTime(dayStart, hhmm) {
    const [h, m] = hhmm.split(':').map(Number);
    return new Date(dayStart.getTime() + (h * 60 + m) * MINUTE_MS);
}

export declare const PHONE_REGEX: RegExp;

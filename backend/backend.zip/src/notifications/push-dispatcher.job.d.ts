import { NotificationsService } from './notifications.service';
export declare class PushDispatcherJob {
    private readonly notifications;
    private readonly logger;
    private running;
    constructor(notifications: NotificationsService);
    tick(): Promise<void>;
}

"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var NotificationsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationsService = exports.MAX_PUSH_ATTEMPTS = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../prisma/prisma.service");
const device_tokens_service_1 = require("./device-tokens.service");
const push_service_1 = require("./push.service");
exports.MAX_PUSH_ATTEMPTS = 3;
const MAX_PUSH_AGE_MS = 6 * 60 * 60 * 1000;
const SEND_CONCURRENCY = 20;
let NotificationsService = NotificationsService_1 = class NotificationsService {
    prisma;
    push;
    devices;
    logger = new common_1.Logger(NotificationsService_1.name);
    constructor(prisma, push, devices) {
        this.prisma = prisma;
        this.push = push;
        this.devices = devices;
    }
    async createMany(items, tx) {
        if (items.length === 0)
            return [];
        const db = tx ?? this.prisma;
        const ids = [];
        for (let i = 0; i < items.length; i += 1000) {
            const chunk = items.slice(i, i + 1000);
            const created = await db.notification.createManyAndReturn({
                data: chunk.map((n) => ({
                    userId: n.userId,
                    type: n.type,
                    title: n.title,
                    body: n.body,
                    relatedEntityId: n.relatedEntityId,
                    data: n.data ?? client_1.Prisma.JsonNull,
                })),
                skipDuplicates: true,
                select: { id: true },
            });
            ids.push(...created.map((c) => c.id));
        }
        return ids;
    }
    async notify(items) {
        try {
            const ids = await this.createMany(items);
            await this.dispatch(ids);
        }
        catch (err) {
            this.logger.error(`notify failed: ${err.message}`);
        }
    }
    async dispatch(ids) {
        if (ids.length === 0)
            return;
        const rows = await this.prisma.notification.findMany({
            where: { id: { in: ids }, pushStatus: client_1.PushStatus.PENDING },
        });
        await this.process(rows);
    }
    async dispatchPending(limit = 200) {
        const rows = await this.prisma.notification.findMany({
            where: {
                pushStatus: client_1.PushStatus.PENDING,
                pushAttempts: { lt: exports.MAX_PUSH_ATTEMPTS },
                createdAt: { gt: new Date(Date.now() - MAX_PUSH_AGE_MS) },
            },
            orderBy: { createdAt: 'asc' },
            take: limit,
        });
        await this.process(rows);
        await this.prisma.notification.updateMany({
            where: {
                pushStatus: client_1.PushStatus.PENDING,
                OR: [
                    { pushAttempts: { gte: exports.MAX_PUSH_ATTEMPTS } },
                    { createdAt: { lte: new Date(Date.now() - MAX_PUSH_AGE_MS) } },
                ],
            },
            data: { pushStatus: client_1.PushStatus.FAILED },
        });
        return rows.length;
    }
    async process(candidates) {
        if (candidates.length === 0)
            return;
        const claimed = [];
        for (const row of candidates) {
            const claim = await this.prisma.notification.updateMany({
                where: { id: row.id, pushStatus: client_1.PushStatus.PENDING, pushAttempts: row.pushAttempts },
                data: { pushAttempts: { increment: 1 } },
            });
            if (claim.count === 1)
                claimed.push({ ...row, pushAttempts: row.pushAttempts + 1 });
        }
        if (claimed.length === 0)
            return;
        if (!this.push.isEnabled()) {
            await this.setStatus(claimed.map((c) => c.id), client_1.PushStatus.SKIPPED);
            return;
        }
        const userIds = [...new Set(claimed.map((c) => c.userId))];
        const users = await this.prisma.user.findMany({
            where: { id: { in: userIds } },
            select: { id: true, notificationsEnabled: true, accountStatus: true },
        });
        const allowed = new Set(users
            .filter((u) => u.notificationsEnabled && u.accountStatus === client_1.AccountStatus.ACTIVE)
            .map((u) => u.id));
        const blocked = claimed.filter((c) => !allowed.has(c.userId));
        await this.setStatus(blocked.map((c) => c.id), client_1.PushStatus.SKIPPED);
        const sendable = claimed.filter((c) => allowed.has(c.userId));
        const tokensByUser = await this.devices.tokensForUsers([...new Set(sendable.map((c) => c.userId))]);
        for (let i = 0; i < sendable.length; i += SEND_CONCURRENCY) {
            await Promise.all(sendable.slice(i, i + SEND_CONCURRENCY).map((n) => this.sendOne(n, tokensByUser.get(n.userId) ?? [])));
        }
    }
    async sendOne(n, tokens) {
        if (tokens.length === 0) {
            await this.setStatus([n.id], client_1.PushStatus.SKIPPED);
            return;
        }
        try {
            const results = await this.push.send(tokens.map((t) => t.token), {
                title: n.title,
                body: n.body,
                collapseKey: n.id,
                data: {
                    ...(n.data ?? {}),
                    notificationId: n.id,
                    type: n.type,
                },
            });
            const dead = results.filter((r) => r.permanentTokenFailure).map((r) => r.token);
            if (dead.length > 0) {
                await this.devices.removeByIds(tokens.filter((t) => dead.includes(t.token)).map((t) => t.id));
            }
            if (results.some((r) => r.ok)) {
                await this.prisma.notification.update({
                    where: { id: n.id },
                    data: { pushStatus: client_1.PushStatus.SENT, pushedAt: new Date() },
                });
            }
            else if (results.every((r) => r.permanentTokenFailure)) {
                await this.setStatus([n.id], client_1.PushStatus.SKIPPED);
            }
            else if (n.pushAttempts >= exports.MAX_PUSH_ATTEMPTS) {
                await this.setStatus([n.id], client_1.PushStatus.FAILED);
            }
        }
        catch (err) {
            this.logger.warn(`Push send failed for notification ${n.id}: ${err.message}`);
            if (n.pushAttempts >= exports.MAX_PUSH_ATTEMPTS)
                await this.setStatus([n.id], client_1.PushStatus.FAILED);
        }
    }
    async setStatus(ids, status) {
        if (ids.length === 0)
            return;
        await this.prisma.notification.updateMany({ where: { id: { in: ids } }, data: { pushStatus: status } });
    }
    async list(userId, limit = 30, before) {
        const rows = await this.prisma.notification.findMany({
            where: { userId, ...(before ? { createdAt: { lt: new Date(before) } } : {}) },
            orderBy: { createdAt: 'desc' },
            take: limit + 1,
            select: {
                id: true,
                type: true,
                title: true,
                body: true,
                data: true,
                isRead: true,
                readAt: true,
                createdAt: true,
            },
        });
        const hasMore = rows.length > limit;
        const items = hasMore ? rows.slice(0, limit) : rows;
        const unreadCount = await this.prisma.notification.count({ where: { userId, isRead: false } });
        return {
            items,
            unreadCount,
            nextCursor: hasMore ? items[items.length - 1].createdAt.toISOString() : null,
        };
    }
    async markRead(userId, id) {
        const res = await this.prisma.notification.updateMany({
            where: { id, userId, isRead: false },
            data: { isRead: true, readAt: new Date() },
        });
        if (res.count === 0) {
            const exists = await this.prisma.notification.findFirst({ where: { id, userId }, select: { id: true } });
            if (!exists)
                throw new common_1.NotFoundException('Notification not found');
        }
    }
    async markAllRead(userId) {
        await this.prisma.notification.updateMany({
            where: { userId, isRead: false },
            data: { isRead: true, readAt: new Date() },
        });
    }
};
exports.NotificationsService = NotificationsService;
exports.NotificationsService = NotificationsService = NotificationsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        push_service_1.PushService,
        device_tokens_service_1.DeviceTokensService])
], NotificationsService);

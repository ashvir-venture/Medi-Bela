"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TokenCryptoService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const crypto_1 = require("crypto");
let TokenCryptoService = class TokenCryptoService {
    key;
    constructor(config) {
        const raw = config.getOrThrow('PUSH_TOKEN_ENC_KEY');
        const key = Buffer.from(raw, 'base64');
        if (key.length !== 32) {
            throw new Error('PUSH_TOKEN_ENC_KEY must be base64 of exactly 32 bytes');
        }
        this.key = key;
    }
    hash(token) {
        return (0, crypto_1.createHmac)('sha256', this.key).update(token, 'utf8').digest('hex');
    }
    encrypt(token) {
        const iv = (0, crypto_1.randomBytes)(12);
        const cipher = (0, crypto_1.createCipheriv)('aes-256-gcm', this.key, iv);
        const ciphertext = Buffer.concat([cipher.update(token, 'utf8'), cipher.final()]);
        const tag = cipher.getAuthTag();
        return ['v1', iv.toString('base64url'), tag.toString('base64url'), ciphertext.toString('base64url')].join('.');
    }
    decrypt(payload) {
        const [version, iv, tag, ciphertext] = payload.split('.');
        if (version !== 'v1' || !iv || !tag || !ciphertext) {
            throw new Error('Unsupported token payload');
        }
        const decipher = (0, crypto_1.createDecipheriv)('aes-256-gcm', this.key, Buffer.from(iv, 'base64url'));
        decipher.setAuthTag(Buffer.from(tag, 'base64url'));
        return Buffer.concat([
            decipher.update(Buffer.from(ciphertext, 'base64url')),
            decipher.final(),
        ]).toString('utf8');
    }
};
exports.TokenCryptoService = TokenCryptoService;
exports.TokenCryptoService = TokenCryptoService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], TokenCryptoService);

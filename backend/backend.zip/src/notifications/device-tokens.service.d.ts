import { PrismaService } from '../prisma/prisma.service';
import { TokenCryptoService } from './token-crypto.service';
import { RegisterDeviceDto } from './dto/register-device.dto';
export interface UserDeviceToken {
    id: string;
    userId: string;
    token: string;
}
export declare class DeviceTokensService {
    private readonly prisma;
    private readonly crypto;
    private readonly logger;
    constructor(prisma: PrismaService, crypto: TokenCryptoService);
    register(userId: string, dto: RegisterDeviceDto): Promise<void>;
    unregister(userId: string, token: string): Promise<void>;
    tokensForUsers(userIds: string[]): Promise<Map<string, UserDeviceToken[]>>;
    removeByIds(ids: string[]): Promise<void>;
}

import { DevicePlatform } from '@prisma/client';
export declare class RegisterDeviceDto {
    token: string;
    platform: DevicePlatform;
    appVersion?: string;
    previousToken?: string;
}
export declare class UnregisterDeviceDto {
    token: string;
}

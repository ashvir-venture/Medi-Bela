export declare class ListNotificationsDto {
    limit?: number;
    before?: string;
}

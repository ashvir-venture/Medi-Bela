"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var PushDispatcherJob_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PushDispatcherJob = void 0;
const common_1 = require("@nestjs/common");
const schedule_1 = require("@nestjs/schedule");
const notifications_service_1 = require("./notifications.service");
let PushDispatcherJob = PushDispatcherJob_1 = class PushDispatcherJob {
    notifications;
    logger = new common_1.Logger(PushDispatcherJob_1.name);
    running = false;
    constructor(notifications) {
        this.notifications = notifications;
    }
    async tick() {
        if (this.running || process.env.PUSH_DISPATCH_JOB_ENABLED === 'false')
            return;
        this.running = true;
        const deadline = Date.now() + 50_000;
        try {
            let processed;
            do {
                processed = await this.notifications.dispatchPending(200);
            } while (processed === 200 && Date.now() < deadline);
        }
        catch (err) {
            this.logger.error(`Push dispatch tick failed: ${err.message}`);
        }
        finally {
            this.running = false;
        }
    }
};
exports.PushDispatcherJob = PushDispatcherJob;
__decorate([
    (0, schedule_1.Cron)(schedule_1.CronExpression.EVERY_MINUTE),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], PushDispatcherJob.prototype, "tick", null);
exports.PushDispatcherJob = PushDispatcherJob = PushDispatcherJob_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [notifications_service_1.NotificationsService])
], PushDispatcherJob);

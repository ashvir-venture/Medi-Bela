"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.messages = void 0;
const client_1 = require("@prisma/client");
const clip = (value, max) => value.length <= max ? value : `${value.slice(0, max - 1).trimEnd()}…`;
exports.messages = {
    missedDoseFamily(lang, memberName) {
        const name = clip(memberName, 40);
        return lang === client_1.Language.BN
            ? {
                title: 'ওষুধ মিস হয়েছে',
                body: `${name} নির্ধারিত সময়ে একটি ওষুধ খাননি। অনুগ্রহ করে খোঁজ নিন।`,
            }
            : {
                title: 'Missed medicine',
                body: `${name} missed a scheduled medicine. Please check in with them.`,
            };
    },
    prescriptionCompleted(lang) {
        return lang === client_1.Language.BN
            ? {
                title: 'প্রেসক্রিপশন প্রস্তুত',
                body: 'আপনার প্রেসক্রিপশনের পর্যালোচনা সম্পন্ন হয়েছে। আপনার ওষুধের রুটিন এখন প্রস্তুত।',
            }
            : {
                title: 'Prescription reviewed',
                body: 'Your prescription has been reviewed and your medicine routine is ready.',
            };
    },
    prescriptionRejected(lang) {
        return lang === client_1.Language.BN
            ? {
                title: 'প্রেসক্রিপশনের হালনাগাদ',
                body: 'আপনার প্রেসক্রিপশনটি প্রক্রিয়া করা যায়নি। বিস্তারিত দেখতে অ্যাপ খুলুন।',
            }
            : {
                title: 'Prescription update',
                body: 'Your prescription could not be processed. Open the app for details.',
            };
    },
    familyInvitation(lang, inviterName) {
        const name = clip(inviterName, 40);
        return lang === client_1.Language.BN
            ? {
                title: 'পরিবারে যোগদানের আমন্ত্রণ',
                body: `${name} আপনাকে তাঁর পরিবারে যোগ দিতে আমন্ত্রণ জানিয়েছেন।`,
            }
            : {
                title: 'Family invitation',
                body: `${name} invited you to join their family.`,
            };
    },
    notice(title, content) {
        return { title: clip(title, 80), body: clip(content.replace(/\s+/g, ' ').trim(), 120) };
    },
};

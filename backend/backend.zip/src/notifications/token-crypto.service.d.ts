import { ConfigService } from '@nestjs/config';
export declare class TokenCryptoService {
    private readonly key;
    constructor(config: ConfigService);
    hash(token: string): string;
    encrypt(token: string): string;
    decrypt(payload: string): string;
}

import { DeviceTokensService } from './device-tokens.service';
import { NotificationsService } from './notifications.service';
import { RegisterDeviceDto, UnregisterDeviceDto } from './dto/register-device.dto';
import { ListNotificationsDto } from './dto/list-notifications.dto';
export declare class NotificationsController {
    private readonly notifications;
    private readonly devices;
    constructor(notifications: NotificationsService, devices: DeviceTokensService);
    list(userId: string, query: ListNotificationsDto): Promise<{
        items: {
            id: string;
            createdAt: Date;
            data: import("@prisma/client/runtime/library").JsonValue;
            type: import("@prisma/client").$Enums.NotificationType;
            title: string;
            body: string;
            isRead: boolean;
            readAt: Date;
        }[];
        unreadCount: number;
        nextCursor: string;
    }>;
    readAll(userId: string): Promise<void>;
    registerDevice(userId: string, dto: RegisterDeviceDto): Promise<void>;
    unregisterDevice(userId: string, dto: UnregisterDeviceDto): Promise<void>;
    read(userId: string, id: string): Promise<void>;
}

import { NotificationType, Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { DeviceTokensService } from './device-tokens.service';
import { PushService } from './push.service';
export declare const MAX_PUSH_ATTEMPTS = 3;
export interface NewNotification {
    userId: string;
    type: NotificationType;
    title: string;
    body: string;
    relatedEntityId: string;
    data?: Record<string, string>;
}
export declare class NotificationsService {
    private readonly prisma;
    private readonly push;
    private readonly devices;
    private readonly logger;
    constructor(prisma: PrismaService, push: PushService, devices: DeviceTokensService);
    createMany(items: NewNotification[], tx?: Prisma.TransactionClient): Promise<string[]>;
    notify(items: NewNotification[]): Promise<void>;
    dispatch(ids: string[]): Promise<void>;
    dispatchPending(limit?: number): Promise<number>;
    private process;
    private sendOne;
    private setStatus;
    list(userId: string, limit?: number, before?: string): Promise<{
        items: {
            id: string;
            createdAt: Date;
            data: Prisma.JsonValue;
            type: import("@prisma/client").$Enums.NotificationType;
            title: string;
            body: string;
            isRead: boolean;
            readAt: Date;
        }[];
        unreadCount: number;
        nextCursor: string;
    }>;
    markRead(userId: string, id: string): Promise<void>;
    markAllRead(userId: string): Promise<void>;
}

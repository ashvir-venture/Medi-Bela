"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var DeviceTokensService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeviceTokensService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma/prisma.service");
const token_crypto_service_1 = require("./token-crypto.service");
const MAX_TOKENS_PER_USER = 5;
let DeviceTokensService = DeviceTokensService_1 = class DeviceTokensService {
    prisma;
    crypto;
    logger = new common_1.Logger(DeviceTokensService_1.name);
    constructor(prisma, crypto) {
        this.prisma = prisma;
        this.crypto = crypto;
    }
    async register(userId, dto) {
        const tokenHash = this.crypto.hash(dto.token);
        const tokenEnc = this.crypto.encrypt(dto.token);
        const now = new Date();
        await this.prisma.$transaction(async (tx) => {
            if (dto.previousToken && dto.previousToken !== dto.token) {
                await tx.deviceToken.deleteMany({
                    where: { userId, tokenHash: this.crypto.hash(dto.previousToken) },
                });
            }
            await tx.deviceToken.upsert({
                where: { tokenHash },
                create: {
                    userId,
                    tokenHash,
                    tokenEnc,
                    platform: dto.platform,
                    appVersion: dto.appVersion ?? null,
                    lastSeenAt: now,
                },
                update: {
                    userId,
                    tokenEnc,
                    platform: dto.platform,
                    appVersion: dto.appVersion ?? null,
                    lastSeenAt: now,
                },
            });
            const mine = await tx.deviceToken.findMany({
                where: { userId },
                orderBy: { lastSeenAt: 'desc' },
                select: { id: true },
            });
            if (mine.length > MAX_TOKENS_PER_USER) {
                await tx.deviceToken.deleteMany({
                    where: { id: { in: mine.slice(MAX_TOKENS_PER_USER).map((t) => t.id) } },
                });
            }
        });
    }
    async unregister(userId, token) {
        await this.prisma.deviceToken.deleteMany({
            where: { userId, tokenHash: this.crypto.hash(token) },
        });
    }
    async tokensForUsers(userIds) {
        const result = new Map();
        if (userIds.length === 0)
            return result;
        const rows = await this.prisma.deviceToken.findMany({
            where: { userId: { in: userIds } },
            select: { id: true, userId: true, tokenEnc: true },
        });
        for (const row of rows) {
            try {
                const entry = { id: row.id, userId: row.userId, token: this.crypto.decrypt(row.tokenEnc) };
                const list = result.get(row.userId) ?? [];
                list.push(entry);
                result.set(row.userId, list);
            }
            catch {
                this.logger.warn(`Dropping undecryptable device token ${row.id}`);
                await this.prisma.deviceToken.delete({ where: { id: row.id } }).catch(() => undefined);
            }
        }
        return result;
    }
    async removeByIds(ids) {
        if (ids.length === 0)
            return;
        await this.prisma.deviceToken.deleteMany({ where: { id: { in: ids } } });
    }
};
exports.DeviceTokensService = DeviceTokensService;
exports.DeviceTokensService = DeviceTokensService = DeviceTokensService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        token_crypto_service_1.TokenCryptoService])
], DeviceTokensService);

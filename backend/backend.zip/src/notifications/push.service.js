"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var PushService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PushService = exports.ANDROID_CHANNEL_ID = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const app_1 = require("firebase-admin/app");
const messaging_1 = require("firebase-admin/messaging");
const PERMANENT_TOKEN_ERRORS = new Set([
    'messaging/registration-token-not-registered',
    'messaging/invalid-registration-token',
]);
exports.ANDROID_CHANNEL_ID = 'carebridge_alerts';
let PushService = PushService_1 = class PushService {
    config;
    logger = new common_1.Logger(PushService_1.name);
    messaging = null;
    constructor(config) {
        this.config = config;
    }
    onModuleInit() {
        try {
            const app = this.buildApp();
            if (app) {
                this.messaging = (0, messaging_1.getMessaging)(app);
                this.logger.log('FCM push enabled');
            }
            else {
                this.logger.warn('FCM credentials not configured — push notifications are DISABLED (inbox still works)');
            }
        }
        catch (err) {
            this.logger.error(`FCM initialisation failed — push disabled: ${err.message}`);
        }
    }
    isEnabled() {
        return this.messaging !== null;
    }
    async send(tokens, message) {
        if (!this.messaging || tokens.length === 0)
            return [];
        const response = await this.messaging.sendEachForMulticast({
            tokens,
            notification: { title: message.title, body: message.body },
            data: message.data,
            android: {
                priority: 'high',
                collapseKey: message.collapseKey,
                notification: { channelId: exports.ANDROID_CHANNEL_ID, tag: message.collapseKey },
            },
            apns: {
                headers: { 'apns-collapse-id': message.collapseKey.slice(0, 64) },
                payload: { aps: { sound: 'default' } },
            },
        });
        return response.responses.map((r, i) => ({
            token: tokens[i],
            ok: r.success,
            permanentTokenFailure: !r.success && PERMANENT_TOKEN_ERRORS.has(r.error?.code ?? ''),
            errorCode: r.error?.code,
        }));
    }
    buildApp() {
        const existing = (0, app_1.getApps)()[0];
        if (existing)
            return existing;
        const b64 = this.config.get('FIREBASE_SERVICE_ACCOUNT_BASE64');
        const json = this.config.get('FIREBASE_SERVICE_ACCOUNT_JSON');
        if (b64 || json) {
            const raw = b64 ? Buffer.from(b64, 'base64').toString('utf8') : json;
            return (0, app_1.initializeApp)({ credential: (0, app_1.cert)(JSON.parse(raw)) });
        }
        if (this.config.get('GOOGLE_APPLICATION_CREDENTIALS')) {
            return (0, app_1.initializeApp)({ credential: (0, app_1.applicationDefault)() });
        }
        return null;
    }
};
exports.PushService = PushService;
exports.PushService = PushService = PushService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], PushService);

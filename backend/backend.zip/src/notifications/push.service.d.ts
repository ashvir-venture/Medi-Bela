import { OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
export interface PushMessage {
    title: string;
    body: string;
    data: Record<string, string>;
    collapseKey: string;
}
export interface PushSendResult {
    token: string;
    ok: boolean;
    permanentTokenFailure: boolean;
    errorCode?: string;
}
export declare const ANDROID_CHANNEL_ID = "carebridge_alerts";
export declare class PushService implements OnModuleInit {
    private readonly config;
    private readonly logger;
    private messaging;
    constructor(config: ConfigService);
    onModuleInit(): void;
    isEnabled(): boolean;
    send(tokens: string[], message: PushMessage): Promise<PushSendResult[]>;
    private buildApp;
}

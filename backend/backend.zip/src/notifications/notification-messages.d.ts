import { Language } from '@prisma/client';
export interface MessageCopy {
    title: string;
    body: string;
}
export declare const messages: {
    missedDoseFamily(lang: Language, memberName: string): MessageCopy;
    prescriptionCompleted(lang: Language): MessageCopy;
    prescriptionRejected(lang: Language): MessageCopy;
    familyInvitation(lang: Language, inviterName: string): MessageCopy;
    notice(title: string, content: string): MessageCopy;
};
